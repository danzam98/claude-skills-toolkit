---
name: claude-skills-toolkit
description: A comprehensive collection of 44 powerful skills for Claude Code — code review, bug hunting, ideation, planning, refactoring, testing, deployment, multi-agent coordination, and more.
---

---

# Agent Swarm Launcher

First read ALL of the AGENTS.md file and README.md file super carefully and understand ALL of both! Then use your code investigation agent mode to fully understand the code, and technical architecture and purpose of the project. Then register with MCP Agent Mail and introduce yourself to the other agents. Be sure to check your agent mail and to promptly respond if needed to any messages; then proceed meticulously with your next assigned beads, working on the tasks systematically and meticulously and tracking your progress via beads and agent mail messages. Don't get stuck in "communication purgatory" where nothing is getting done; be proactive about starting tasks that need to be done, but inform your fellow agents via messages when you do so and mark beads appropriately. When you're not sure what to do next, use the bv tool mentioned in AGENTS.md to prioritize the best beads to work on next; pick the next one that you can usefully work on and get started. Make sure to acknowledge all communication requests from other agents and that you are aware of all active agents and their names.

## When to Use

- When launching multiple agents on a project
- For coordinated multi-agent workflows
- When using beads task management with agent mail

## Tips

- Requires Agent Mail MCP server to be running
- Works with beads (br) for task management
- Prevents agents from duplicating work

## NTM Workflow Skills

Related skills for NTM (Named Tmux Manager) agent swarm workflows:

| Skill | Command | Purpose |
|-------|---------|---------|
| ntm-start-agent | `/ntm-start-agent` | Initialize worker agents |
| ntm-git-manager | `/ntm-git-manager` | Designate git coordinator (sticky role) |
| ntm-next-bead | `/ntm-next-bead` | Move to next priority task |
| ntm-review-own | `/ntm-review-own` | Self-review for bugs |
| ntm-review-others | `/ntm-review-others` | Cross-agent code review |
| ntm-bug-hunt | `/ntm-bug-hunt` | Random codebase exploration |
| ntm-commit-all | `/ntm-commit-all` | Commit changes in logical groups |
| ntm-ui-polish | `/ntm-ui-polish` | UI/UX refinement pass |
| ntm-test-coverage | `/ntm-test-coverage` | Test coverage audit |
| ntm-reread-agents | `/ntm-reread-agents` | Refresh context after compaction |

### Quick Start Workflow

```bash
# Setup - spawn agents with NTM
ntm add myproject --cc=3

# Designate git manager (pane 1)
ntm send myproject --pane=1
# Then type: /ntm-git-manager

# Start worker agents (all other panes)
ntm send myproject --cc
# Then type: /ntm-start-agent

# Work loop - after completing tasks
ntm send myproject --cc
# Then type: /ntm-review-own
# Then type: /ntm-next-bead

# Periodic - commit and cross-review
ntm send myproject --pane=1
# Then type: /ntm-commit-all

ntm send myproject --cc
# Then type: /ntm-review-others

# After context compaction
ntm send myproject --cc
# Then type: /ntm-reread-agents
```

**Note:** The git manager role is "sticky" - it will ignore worker prompts sent via `--cc`.

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/agent-swarm-launcher)*

---

<!-- TOC: Philosophy | THE EXACT PROMPT | Decision Tree | Command Map | Transform Patterns | Validation Loop | Risk Tiers | References -->

# bd → br Migration

> **Core Philosophy:** One behavioral change, mechanical transforms. The ONLY difference is git handling—everything else is find-replace.

## Why This Matters

Incomplete migrations leave broken docs. Agents follow stale `bd sync` instructions, expect auto-commit, and lose work. This skill ensures **complete, verified migrations**.

---

## THE EXACT PROMPT — Single File Migration

```
Migrate this file from bd (beads) to br (beads_rust).

Apply transforms IN THIS ORDER (order matters):
1. Section headers: "bd (beads)" → "br (beads_rust)"
2. Add non-invasive note after beads section header
3. Commands: `bd X` → `br X` for ready/list/show/create/update/close/dep/stats
4. Sync command: `bd sync` → `br sync --flush-only`
5. Add git steps after EVERY sync:
   git add .beads/
   git commit -m "sync beads"
6. Issue IDs: bd-### → br-### in thread_ids, subjects, reasons, commits
7. Links: beads_viewer → beads_rust (if present)

Remove completely:
- Daemon references
- Auto-commit assumptions
- Hook installation mentions
- RPC mode

Keep unchanged:
- SQLite/WAL cautions
- bv integration
- Priority system (P0-P4)

VERIFY after editing:
grep -c '`bd ' file.md     # Must be 0
grep -c 'bd sync' file.md  # Must be 0
grep -c 'br sync --flush-only' file.md  # Must be > 0
```

### Why This Prompt Works

- **Ordered transforms**: Dependencies exist (sync must change before adding git steps)
- **Explicit removals**: Daemon/RPC don't exist in br—leaving them confuses agents
- **Keep list**: Prevents accidental removal of still-valid patterns
- **Built-in verification**: Grep commands catch missed transforms
- **No degrees of freedom**: This is a LOW freedom task—exact transforms required

---

## Decision Tree: What Are You Migrating?

```
What are you migrating?
│
├─ Single file (AGENTS.md)
│  │
│  └─ Follow THE EXACT PROMPT above
│     Use: ./scripts/verify-migration.sh file.md
│
├─ Multiple files (batch)
│  │
│  ├─ <10 files → Sequential: apply prompt to each
│  │
│  └─ 10+ files → Parallel subagents
│     Batch ~10 files per agent
│     See: [BULK.md](references/BULK.md)
│
└─ Verify existing migration
   │
   └─ Run: ./scripts/find-bd-refs.sh /path
      Any output = incomplete migration
```

---

## The One Behavioral Difference

```
┌─────────────────────────────────────────────────────────────────┐
│                    bd (Go)              br (Rust)               │
├─────────────────────────────────────────────────────────────────┤
│  bd sync                     →    br sync --flush-only          │
│  (auto-commits to git)            (exports JSONL only)          │
│                                                                 │
│                              +    git add .beads/               │
│                              +    git commit -m "..."           │
└─────────────────────────────────────────────────────────────────┘

Everything else is literally s/bd/br/g
```

---

## Command Map

| bd | br | Change Type |
|----|-----|-------------|
| `bd ready` | `br ready` | Name only |
| `bd list` | `br list` | Name only |
| `bd show <id>` | `br show <id>` | Name only |
| `bd create` | `br create` | Name only |
| `bd update` | `br update` | Name only |
| `bd close` | `br close` | Name only |
| `bd dep add` | `br dep add` | Name only |
| `bd stats` | `br stats` | Name only |
| `bd sync` | `br sync --flush-only` + git | **BEHAVIORAL** |

---

## Transform Patterns

### Pattern 1: The Non-Invasive Note

**Add immediately after any beads section header:**

```markdown
**Note:** `br` is non-invasive and never executes git commands. After `br sync --flush-only`, you must manually run `git add .beads/ && git commit`.
```

### Pattern 2: Sync Command Transform

**Before:**
```bash
bd sync
```

**After:**
```bash
br sync --flush-only
git add .beads/
git commit -m "sync beads"
```

### Pattern 3: Session End Transform

**Before:**
```bash
git add <files>
bd sync
git push
```

**After:**
```bash
git add <files>
br sync --flush-only
git add .beads/
git commit -m "..."
git push
```

### Pattern 4: Issue ID Transform

**Before:**
```markdown
thread_id: bd-123
subject: [bd-123] Feature implementation
reason: bd-123
```

**After:**
```markdown
thread_id: br-123
subject: [br-123] Feature implementation
reason: br-123
```

---

## Validation Loop

```
┌─────────────────────────────────────────────────────────────────┐
│                     VALIDATION IS MANDATORY                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. Apply transforms                                            │
│                    ↓                                            │
│  2. Run verification:                                           │
│     ./scripts/verify-migration.sh file.md                       │
│                    ↓                                            │
│  3. If FAIL → read error → fix specific issue → goto 2          │
│                    ↓                                            │
│  4. Only proceed when PASS                                      │
│                                                                 │
│  ⚠️ Never skip verification. Incomplete migrations break agents.│
└─────────────────────────────────────────────────────────────────┘
```

### Quick Verification Commands

```bash
# MUST return 0:
grep -c '`bd ' file.md
grep -c 'bd sync' file.md
grep -c 'bd ready' file.md

# MUST return > 0 (if file has sync sections):
grep -c 'br sync --flush-only' file.md
grep -c 'git add .beads/' file.md
```

---

## Risk Tiers

| Operation | Risk | Freedom |
|-----------|------|---------|
| Command renames (`bd` → `br`) | Low | Mechanical—no judgment |
| Sync transform + git steps | Medium | MUST add git steps |
| Removing daemon refs | Medium | Verify not removing valid content |
| Bulk migration (10+ files) | High | Use subagents with verification |

### Degrees of Freedom: LOW

This is a **deterministic transformation**. There is ONE correct output for each input.

- No creative interpretation
- No optional improvements
- No stylistic choices
- Apply transforms EXACTLY as specified

---

## What Gets Removed

| Pattern | Why Remove | Verify Absent |
|---------|------------|---------------|
| "bd daemon" | br has no daemon | `grep -i daemon` |
| "auto-commits" | br never commits | `grep -i "auto.*commit"` |
| "git hooks" | br installs none | `grep -i "hook"` |
| "RPC mode" | br has no RPC | `grep -i "rpc"` |

---

## What Stays Unchanged

| Pattern | Why Keep |
|---------|----------|
| SQLite/WAL cautions | br still uses WAL |
| bv integration | Works with both |
| Priority P0-P4 | Same system |
| Issue types | Same system |
| Dependency tracking | Same system |
| `.beads/` as source of truth | Same system |

---

## Before/After Example

### Before (bd)
```markdown
## Issue Tracking with bd (beads)

Key invariants:
- `.beads/` is authoritative

### Agent workflow:
1. `bd ready` to find work
2. `bd update <id> --status in_progress`
3. Implement
4. `bd close <id>`
5. `bd sync` commits changes
```

### After (br)
```markdown
## Issue Tracking with br (beads_rust)

**Note:** `br` is non-invasive and never executes git commands. After `br sync --flush-only`, you must manually run `git add .beads/ && git commit`.

Key invariants:
- `.beads/` is authoritative

### Agent workflow:
1. `br ready` to find work
2. `br update <id> --status in_progress`
3. Implement
4. `br close <id>`
5. Sync and commit:
   ```bash
   br sync --flush-only
   git add .beads/
   git commit -m "sync beads"
   ```
```

---

## References

| Need | Reference |
|------|-----------|
| Complete before/after examples | [TRANSFORMS.md](references/TRANSFORMS.md) |
| Bulk migration strategy | [BULK.md](references/BULK.md) |
| Common mistakes & fixes | [PITFALLS.md](references/PITFALLS.md) |

---

## Scripts

| Script | Purpose |
|--------|---------|
| `./scripts/find-bd-refs.sh /path` | Find files needing migration |
| `./scripts/verify-migration.sh file.md` | Verify migration complete |

---

## Validation

```bash
# Full verification
./scripts/verify-migration.sh /path/to/AGENTS.md

# Quick check (should return nothing)
grep '`bd ' /path/to/AGENTS.md
```

If any bd references remain → migration incomplete → re-apply transforms.

---

# Bug Hunt

Systematically explore the codebase to find bugs, inefficiencies, security issues, and reliability problems.

## What This Does

Unlike focused code review, bug hunting is **exploratory investigation**:
- Randomly explore code files to find hidden issues
- Trace execution flows through the system
- Look for bugs, inefficiencies, security holes, reliability problems
- Check error handling paths and edge cases
- Report findings with severity, location, and suggested fixes

## How to Use

1. **General investigation:** `/bug-hunt` — explore entire codebase
2. **Focused hunt:** `/bug-hunt <directory>` — target specific area
3. **Security focus:** `/bug-hunt --security` — prioritize security issues
4. **Performance focus:** `/bug-hunt --performance` — find inefficiencies

## Instructions

When this skill is invoked:

1. **Random exploration** — Pick 5-10 files semi-randomly:
   - Critical paths (auth, payment, data processing)
   - Recently changed files (more likely to have new bugs)
   - Complex files with high cyclomatic complexity
   - Files with many dependencies

2. **Trace execution flows:**
   - Follow function calls from entry points
   - Check error handling at each step
   - Verify assumptions about data and state
   - Look for edge cases that break logic

3. **Look for common issues:**
   - **Bugs:** Logic errors, race conditions, null/undefined handling, off-by-one errors
   - **Security:** SQL injection, XSS, CSRF, auth bypass, sensitive data exposure
   - **Performance:** N+1 queries, unnecessary loops, missing indexes, memory leaks
   - **Reliability:** Missing error handling, unvalidated input, bad assumptions

4. **Report findings:**
   - **HIGH severity:** Security vulnerabilities, data loss risks, crashes
   - **MEDIUM severity:** Logic bugs, performance issues, reliability problems
   - **LOW severity:** Code smells, minor inefficiencies, style issues

   For each finding:
   - File and line number (e.g., `auth.ts:42`)
   - Description of the issue
   - Why it's a problem (impact)
   - Suggested fix

5. **Offer to fix** — Ask user which issues to fix immediately

## Example Output

```
=== Bug Hunt Report ===

HIGH SEVERITY:
- auth/login.ts:156 — SQL injection in raw query
  Impact: Attacker can dump database
  Fix: Use parameterized query with prepared statement

- api/payments.ts:89 — Missing authentication check
  Impact: Unauthenticated users can process payments
  Fix: Add auth middleware before handler

MEDIUM SEVERITY:
- users/profile.ts:234 — N+1 query in loop
  Impact: 100+ users = 100+ database queries, slow page load
  Fix: Use eager loading or single query with JOIN

- utils/parser.ts:67 — Unhandled exception in JSON.parse
  Impact: Crashes server on malformed input
  Fix: Wrap in try/catch, return error response

LOW SEVERITY:
- components/Header.tsx:34 — Unused import
  Impact: Slightly larger bundle size
  Fix: Remove unused import

Which issues should I fix? (all/high/specific)
```

## Related Skills

- **/fresh-eyes** — Review recent changes, not exploratory
- **/peer-review** — Structured review of specific code/PR

---

# The Bug Hunter

I want you to sort of randomly explore the code files in this project, choosing code files to deeply investigate and understand and trace their functionality and execution flows through the related code files which they import or which they are imported by. Once you understand the purpose of the code in the larger context of the workflows, I want you to do a super careful, methodical, and critical check with "fresh eyes" to find any obvious bugs, problems, errors, issues, silly mistakes, etc. and then systematically and meticulously and intelligently correct them. Be sure to comply with ALL rules in the AGENTS.md file and ensure that any code you write or revise conforms to the best practice guides referenced in the AGENTS.md file.

## When to Use

- After writing a lot of new code
- When you suspect there might be bugs lurking
- As a general code quality check
- To keep agents productively busy exploring and improving code

## Tips

- Great for keeping agents busy with useful work
- Follow up with 'OK, now fix ALL of them' for execution
- Works well after the agent has explored different parts of the codebase

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/bug-hunter)*

---

# CLI Error Tolerance

One thing that's critical for the robot mode flags in the CLI (the mode intended for use by AI coding agents like yourself) is that we want to make it easy for the agents to use the tool; so first off, we want to make the CLI interface and system as intuitive and easy as possible and explain it super clearly in the CLI help and in a blurb in AGENTS.md. But beyond that, we want to be maximally flexible when the intent of a command is clear but there's some minor syntax issue; basically we'd like to honor all commands where the intent is legible (although in those cases we might want to precede the response with some note instructing the agent how to more correctly issue that command in the future). If we can't really figure out reliably what the agent is trying to do, then we should always return a super detailed and helpful/useful error message that lets the agent understand what it did wrong so it can do it the right way next time; we should give them a couple relevant correct examples in the error message about how to do what we might reasonably guess they are trying (and failing) to do with their wrong command.

## When to Use

- When building CLIs that agents will use
- To improve agent-tool interaction success rates
- After Robot-Mode Maker to enhance the interface

## Tips

- Complements Robot-Mode Maker
- Reduces agent frustration with strict syntax
- Include teaching notes in error responses

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/cli-error-tolerance)*

---

# The Code Reorganizer

We really have WAY too many code files scattered inside src/x with no rhyme or reason to the structure and location of code files; I feel like we could make things a lot more organized, logical, intuitive, etc. by reorganizing these into a nice, sensible folder structure, although I don't want something that has too many levels of nesting; basically, we should at least start out with making "no brainer" type changes to the folder structure, like putting all the "x" functionality-related code files into an "x" folder (and perhaps that inside of a data_sources folder which might also contain a "y" folder, etc.).

Before making any of these changes, I really need you to take the time to explore and read ALL of the many, many files in that folder and understand what they do, how they fit together, which code files import which others, how they interact in functional ways, etc., and then propose a reorganization plan in a new document called PROPOSED_CODE_FILE_REORGANIZATION_PLAN.md so I can review it before doing anything; this plan should include not just your detailed reorganization plan but the super-detailed rationale and justification for your proposed file/folder structure and why you think it's optimal for aiding any developer or coding agent working on this project to immediately and intuitively understand the project structure and where to look for things, etc.

I'm also open to merging/consolidating/splitting individual code files; if we have multiple small related code files that you think should be combined into a single code file, explain why. If you think any particular code files are WAY too big and really should be refactored into several smaller code files, then explain that too and your proposed strategy for how to restructure them.

Always keep in mind, and track in this plan document, changes you will need to make to any calling code to properly reflect the new folder structure and file structure so that we don't break anything. I don't want to discover after you do all this that nothing works anymore and we have to do a massive slog to get anything running again properly.

## When to Use

- When your codebase has grown organically and become messy
- When onboarding new developers is difficult due to confusing structure
- When you can't find files intuitively

## Tips

- Replace 'x' and 'y' with your actual folder/feature names
- Make sure no other agents are running when implementing the plan
- Always review the plan document before execution

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/code-reorganizer)*

---

# Cost Estimate Command

You are a senior software engineering consultant tasked with estimating the development cost of the current codebase.

**CRITICAL**: Not all code is created equal. The majority of modern codebases consist of scaffolded, copied, or generated code that should NOT be valued at full custom development rates.

## Step 1: Analyze and CATEGORIZE the Codebase

First, count total lines. Then **categorize each file** into one of these tiers:

### Code Value Tiers

| Tier | Value % | Description | Examples |
|------|---------|-------------|----------|
| **Tier 1: Custom Business Logic** | 100% | Novel code solving unique problems | Custom algorithms, business rules, API handlers with real logic |
| **Tier 2: Custom UI/Components** | 75% | Project-specific UI built from scratch | Custom React components, layouts, animations |
| **Tier 3: Configured Integrations** | 40% | Third-party services wired together | Auth setup, payment integration, API clients |
| **Tier 4: Adapted Library Code** | 15% | Copy-pasted with minor changes | shadcn/ui components, Next.js app router pages |
| **Tier 5: Pure Scaffold/Config** | 5% | Generated or copy-pasted verbatim | Config files, boilerplate, package.json |
| **Tier 6: Content (not code)** | 0% | Text content, documentation | MDX blog posts, README files |

### How to Categorize

**Tier 1 indicators** (100% value):
- Contains business-specific logic (pricing, rules, workflows)
- Has custom algorithms or data transformations
- Non-trivial error handling for real edge cases
- Would require understanding the business to write

**Tier 2 indicators** (75% value):
- Custom UI components built for this project
- Project-specific layouts and page structures
- Custom hooks with real logic
- Styled components with original designs

**Tier 3 indicators** (40% value):
- Integration code (Stripe, Auth0, Cloudflare, etc.)
- API route handlers that mostly call external services
- Database schema definitions
- Queue/worker configurations

**Tier 4 indicators** (15% value):
- Components from shadcn/ui, Radix, or similar
- Next.js/Remix page boilerplate
- Standard CRUD operations
- Copy-pasted patterns from docs

**Tier 5 indicators** (5% value):
- tsconfig.json, eslint.config.js, tailwind.config.js
- package.json, wrangler.toml
- Docker/CI configs from templates
- Generated types, migrations from CLI tools

**Tier 6 indicators** (0% value):
- MDX/Markdown content files
- README, CHANGELOG, docs
- Comments and JSDoc (unless documenting complex logic)

### Categorization Commands

Run these to identify code categories:

```bash
# Find UI library components (Tier 4)
ls src/components/ui/ 2>/dev/null | wc -l

# Find config files (Tier 5)
ls *.config.* *.json wrangler.toml tsconfig.json 2>/dev/null

# Find content files (Tier 6)
find . -name "*.md" -o -name "*.mdx" | wc -l

# Find test files (apply 50% modifier - tests have high boilerplate)
find . -name "*.test.*" -o -name "*.spec.*" | xargs wc -l 2>/dev/null
```

### Calculate Effective Lines of Code

```
Effective LOC = Σ (Lines in Category × Value %)
```

Example:
- 500 lines custom business logic × 100% = 500 effective
- 2000 lines custom UI × 75% = 1500 effective
- 800 lines integrations × 40% = 320 effective
- 3000 lines shadcn/ui × 15% = 450 effective
- 600 lines config × 5% = 30 effective
- 1000 lines content × 0% = 0 effective
- **Total: 7900 raw LOC → 2800 effective LOC**

## Step 2: Calculate Development Hours (using Effective LOC)

Based on industry standards for a **senior full-stack developer** (5+ years experience):

**Hourly Productivity Estimates** (applied to EFFECTIVE lines only):
- Complex business logic: 15-25 lines/hour
- Custom UI/components: 25-40 lines/hour
- Integration code: 30-50 lines/hour
- Standard patterns: 40-60 lines/hour

**Test Code Modifier**: Tests are typically 50% boilerplate. Apply 0.5x to test line counts before categorization.

**Additional Time Factors**:
- Architecture & design: +15% of coding time
- Debugging & troubleshooting: +20% of coding time
- Code review & refactoring: +10% of coding time
- Integration & testing: +15% of coding time

**Calculate total hours**:
```
Base Hours = Effective LOC / Productivity Rate
Total Hours = Base Hours × (1 + Overhead %)
```

## Step 3: Research Market Rates

Use WebSearch to find current hourly rates for senior developers.

Search queries:
- "senior full stack developer hourly rate [current year]"
- "senior software engineer contractor rate United States [current year]"

**Typical ranges (2025-2026)**:
- Remote/mid-market: $75-100/hr
- US average: $100-150/hr
- Premium markets (SF/NYC): $150-200/hr

## Step 4: Calculate Organizational Overhead

Real companies don't have developers coding 40 hours/week.

**Coding Efficiency Factor**:
- **Solo/Startup (lean)**: 65% coding time (~26 hrs/week)
- **Growth company**: 55% coding time (~22 hrs/week)
- **Enterprise**: 45% coding time (~18 hrs/week)

**Calendar Time**:
```
Calendar Weeks = Total Dev Hours / (40 × Efficiency Factor)
```

## Step 5: Generate Cost Estimate

**Important**: Present BOTH the raw LOC count AND the effective LOC calculation to show the methodology clearly.

### Output Format

---

## [Project Name] - Development Cost Estimate

**Analysis Date**: [Current Date]

### Code Categorization

| Category | Raw LOC | Value % | Effective LOC |
|----------|---------|---------|---------------|
| Custom Business Logic (Tier 1) | [X] | 100% | [X] |
| Custom UI/Components (Tier 2) | [X] | 75% | [X] |
| Configured Integrations (Tier 3) | [X] | 40% | [X] |
| Adapted Library Code (Tier 4) | [X] | 15% | [X] |
| Scaffold/Config (Tier 5) | [X] | 5% | [X] |
| Content - not code (Tier 6) | [X] | 0% | 0 |
| **TOTAL** | **[Raw]** | | **[Effective]** |

**Effective LOC Ratio**: [Effective/Raw]% — This is a [typical/lean/heavy] scaffold ratio.

### Development Time Estimate

Using **[Effective LOC]** effective lines:

| Code Type | Effective LOC | Productivity | Hours |
|-----------|---------------|--------------|-------|
| Business Logic | [X] | 20 lines/hr | [X] |
| Custom UI | [X] | 35 lines/hr | [X] |
| Integrations | [X] | 40 lines/hr | [X] |
| Patterns | [X] | 50 lines/hr | [X] |
| **Subtotal** | | | **[X] hrs** |

**Overhead**: +60% (architecture, debugging, review, testing)

**Total Estimated Hours**: [X] hours

### Cost Estimate

| Scenario | Hourly Rate | Total Hours | **Total Cost** |
|----------|-------------|-------------|----------------|
| Low-end | $75 | [X] | **$[X]** |
| Average | $125 | [X] | **$[X]** |
| High-end | $175 | [X] | **$[X]** |

**Recommended Estimate**: **$[X] - $[X]**

### Calendar Time

| Company Type | Efficiency | Calendar Weeks | Calendar Time |
|--------------|------------|----------------|---------------|
| Solo/Startup | 65% | [X] weeks | ~[X] months |
| Growth Company | 55% | [X] weeks | ~[X] months |
| Enterprise | 45% | [X] weeks | ~[X] months |

---

## Step 6: Claude ROI Analysis (if applicable)

If this codebase was built with Claude:

**Project Timeline**:
- First commit: [date]
- Latest commit: [date]
- Total calendar time: [X] days

**Claude Active Hours Estimate**:
Cluster commits into sessions (4-hour windows), estimate 1-4 hours per session based on commit density.

**Value per Claude Hour**:
```
$/Claude Hour = Total Cost Estimate / Claude Active Hours
```

**Speed Multiplier**:
```
Speed = Human Hours / Claude Hours
```

---

## Common Mistakes to Avoid

1. **Counting all lines equally** - A 50K LOC project with 40K lines of scaffolding is NOT a $500K project
2. **Including content as code** - MDX blog posts are writing, not development
3. **Full-valuing test boilerplate** - Test setup/mocking is highly repetitive
4. **Ignoring the scaffold ratio** - Modern frameworks generate 50-80% of typical codebases

## Sanity Checks

Before finalizing, ask:
- Could a competent developer recreate this in [X] weeks? Does the estimate match?
- What % is truly novel vs. "npm install + copy docs"?
- Does the estimate pass the "would I pay this?" test?

A realistic solo web project typically costs **$10K-50K**, not $100K+. Anything higher requires exceptional complexity justification.

---

# The De-Slopifier

I want you to read through the complete text carefully and look for any telltale signs of "AI slop" style writing; one big tell is the use of em dash. You should try to replace this with a semicolon, a comma, or just recast the sentence accordingly so it sounds good while avoiding em dash.

Also, you want to avoid certain telltale writing tropes, like sentences of the form "It's not [just] XYZ, it's ABC" or "Here's why" or "Here's why it matters:". Basically, anything that sounds like the kind of thing an LLM would write disproportionately more commonly that a human writer and which sounds inauthentic/cringe.

And you can't do this sort of thing using regex or a script, you MUST manually read each line of the text and revise it manually in a systematic, methodical, diligent way.

## When to Use

- After generating documentation with AI
- When editing README files
- When polishing any AI-generated text for human readers

## Tips

- Pay special attention to em dashes — they're a dead giveaway
- Watch for 'Here's why' and similar AI-isms
- Read the output aloud to catch unnatural phrasing

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/de-slopify)*

---

# Deep Performance Audit

First read ALL of the AGENTS.md file and README.md file super carefully and understand ALL of both! Then use your code investigation agent mode to fully understand the code, and technical architecture and purpose of the project. Then, once you've done an extremely thorough and meticulous job at all that and deeply understood the entire existing system and what it does, its purpose, and how it is implemented and how all the pieces connect with each other, I need you to hyper-intensively investigate and study and ruminate on these questions as they pertain to this project: are there any other gross inefficiencies in the core system? places in the codebase where 1) changes would actually move the needle in terms of overall latency/responsiveness and throughput; 2) such that our changes would be provably isomorphic in terms of functionality so that we would know for sure that it wouldn't change the resulting outputs given the same inputs; 3) where you have a clear vision to an obviously better approach in terms of algorithms or data structures.

Consider these optimization patterns:
- N+1 query/fetch pattern elimination
- zero-copy / buffer reuse / scatter-gather I/O
- serialization format costs (parse/encode overhead)
- bounded queues + backpressure
- sharding / striped locks to reduce contention
- memoization with cache invalidation strategies
- dynamic programming techniques
- lazy evaluation / deferred computation
- streaming/chunked processing for memory-bounded work
- pre-computation and lookup tables
- index-based lookup vs linear scan recognition
- binary search (on data and on answer space)
- two-pointer and sliding window techniques
- prefix sums / cumulative aggregates

METHODOLOGY REQUIREMENTS:
A) Baseline first: Run the test suite and a representative workload; record p50/p95/p99 latency, throughput, and peak memory with exact commands.
B) Profile before proposing: Capture CPU + allocation + I/O profiles; identify the top 3-5 hotspots by % time before suggesting changes.
C) Equivalence oracle: Define explicit golden outputs + invariants.
D) Isomorphism proof per change: Every proposed diff must include a short proof sketch explaining why outputs cannot change.
E) Opportunity matrix: Rank candidates by (Impact x Confidence) / Effort before implementing.
F) Minimal diffs: One performance lever per change. No unrelated refactors.
G) Regression guardrails: Add benchmark thresholds or monitoring hooks.

## When to Use

- When performance is critical
- Before scaling to production load
- When profiling reveals hotspots

## Tips

- Always profile before optimizing
- Require proof of isomorphism for each change
- One optimization per change for clear attribution

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/deep-performance-audit)*

---

# Deep Project Primer

First read ALL of the AGENTS.md file and README.md file super carefully and understand ALL of both! Then use your code investigation agent mode to fully understand the code, and technical architecture and purpose of the project.

## When to Use

- At the start of any new coding session
- When working on an unfamiliar project
- After context compaction to restore understanding
- Before any major architectural decisions

## Tips

- Always use this before significant work
- Essential for maintaining project coherence
- Prevents agents from making uninformed changes

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/deep-project-primer)*

---

# Deployment Verifier

Deploy to vercel and verify that the deployment worked properly without any errors (iterate and fix if there were errors). Then visit the live site with playwright as both desktop and mobile browser and take screenshots and check for js errors and look at the screenshots for potential problems and iterate and fix them all super carefully!

## When to Use

- After deploying to production
- For automated deployment verification
- To catch runtime issues that static analysis misses

## Tips

- Test both desktop and mobile viewports
- Check browser console for JS errors
- Screenshots help catch visual regressions

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/deployment-verifier)*

---

# E2E Pipeline Validator

We really need to have totally complete, totally comprehensive, granular, perfect end to end testing coverage without ANY mocks or fake data, fake api calls, etc., that prove that our entire pipeline from start to finish works perfectly in a provable, ultra rigorous way. That means the raw data coming in from the various API services for EVERYTHING (not just one or two fields) for a bunch of test cases. Basically, the WHOLE thing, from "soup to nuts".

## When to Use

- Before production releases
- When building critical data pipelines
- To prove system correctness rigorously

## Tips

- No mocks means real confidence in the system
- Cover the entire pipeline, not just individual units
- Essential for data-critical applications

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/e2e-pipeline-validator)*

---

# Fresh Eyes Review

Re-read all recently changed code with "fresh eyes" to catch bugs, errors, and bad assumptions before moving forward.

## What This Does

Systematically review all code that was just written or modified, looking for:
- Obvious bugs, errors, or logic issues
- Bad assumptions or edge cases missed
- Inconsistencies with existing code patterns
- Security vulnerabilities or performance issues
- Code that doesn't match the stated requirements

## How to Use

1. **After any code change:** Run automatically after writing/modifying code
2. **Multiple passes:** User can request 2-3 passes for extra scrutiny
3. **Before committing:** Final check before git commits

## Instructions

When this skill is invoked:

1. **Identify changed files** — Read git diff or ask user which files were modified
2. **Re-read each file completely** — Don't skim, read line by line with fresh perspective
3. **Look for problems:**
   - Logic errors, off-by-one errors, null pointer issues
   - Missing validation, error handling, or edge case coverage
   - Incorrect assumptions about data, state, or control flow
   - Security issues (SQL injection, XSS, auth bypass, etc.)
   - Performance problems (N+1 queries, unnecessary loops, etc.)
4. **Fix immediately** — Don't just report, fix what you find
5. **Report summary** — List what was found and fixed, with file:line references

## Number of Passes

- **Default:** 1 pass
- **User can request:** 2-3 passes for critical code or complex changes
- **Each pass:** Re-read with completely fresh perspective, as if seeing code for first time

## Example Usage

```
User: /fresh-eyes
You: Running fresh eyes review on recent changes...
     [reads git diff, identifies 3 files changed]
     [re-reads each file completely]

     Found and fixed:
     - auth.ts:42 — Missing null check on user object
     - api.ts:156 — SQL injection risk in raw query, switched to parameterized
     - utils.ts:89 — Off-by-one error in loop condition
```

## Related Skills

- **/bug-hunt** — More exploratory, investigates entire codebase
- **/peer-review** — Structured review like a senior developer would do

---

# Gemini Grounded Research

Research using Gemini with Google Search grounding for real-time web information. Returns comprehensive answers with citations.

## What This Does

Calls Google's Gemini API with search grounding enabled to answer research questions using current web data. Perfect for:
- Current events and recent developments
- Product feature comparisons
- Technology research with citations
- Fact-checking with sources
- Market research

## How to Use

```
/gemini-grounded-research "Your research question here"
```

## Examples

```
/gemini-grounded-research "What are Slack's collaborative to-do list and reminder features in 2026?"
/gemini-grounded-research "Compare Stripe vs PayPal payment APIs"
/gemini-grounded-research "What new features did Anthropic Claude launch in 2026?"
```

## How It Works

1. Takes research query as argument
2. Calls Gemini 2.0 Flash via Generative Language API
3. Enables Google Search grounding via `google_search` tool
4. Returns comprehensive answer with web citations

## Prerequisites

- `curl` command-line tool
- `jq` JSON processor
- `GEMINI_API_KEY` environment variable set

To get an API key:
1. Go to https://aistudio.google.com/app/apikey
2. Create a new API key
3. Add to your shell profile: `export GEMINI_API_KEY="your-key-here"`

## Implementation

```bash
#!/bin/bash
set -euo pipefail

QUERY="$*"

if [ -z "$QUERY" ]; then
  echo "Usage: gemini-grounded-research \"your question\""
  exit 1
fi

if [ -z "${GEMINI_API_KEY:-}" ]; then
  echo "Error: GEMINI_API_KEY environment variable not set"
  exit 1
fi

# Call Gemini API with Google Search grounding
RESPONSE=$(curl -s "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -H "Content-Type: application/json" \
  -d @- <<EOF
{
  "contents": [{
    "parts": [{
      "text": "$QUERY"
    }]
  }],
  "tools": [{
    "google_search": {}
  }]
}
EOF
)

# Extract the response text
echo "$RESPONSE" | jq -r '.candidates[0].content.parts[] | select(.text != null) | .text' || {
  echo "Error parsing Gemini response:"
  echo "$RESPONSE" | jq .
  exit 1
}
```

---

# The Git Committer

Now, based on your knowledge of the project, commit all changed files now in a series of logically connected groupings with super detailed commit messages for each and then push. Take your time to do it right. Don't edit the code at all. Don't commit obviously ephemeral files.

## When to Use

- After completing a coding session with multiple changes
- When you have many modified files to commit
- When you want clean, well-organized git history

## Tips

- Best used with a separate agent dedicated to git operations
- Agent will analyze diffs and group related changes
- Great for maintaining clean commit history

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/git-committer)*

---

# The 100-to-10 Filter

I want you to come up with your top 10 most brilliant ideas for adding extremely powerful and cool functionality that will make this system far more compelling, useful, intuitive, versatile, powerful, robust, reliable, etc. Be pragmatic and don't think of features that will be extremely hard to implement or which aren't necessarily worth the additional complexity burden they would introduce. But I don't want you to just think of 10 ideas: I want you to seriously think hard and come up with one HUNDRED ideas and then only tell me your 10 VERY BEST and most brilliant, clever, and radically innovative and powerful ideas.

## When to Use

- When you need truly exceptional ideas, not just good ones
- For major feature planning sessions
- When brainstorming product direction

## Tips

- More rigorous than the Idea Wizard - use when quality matters most
- The 100→10 ratio forces deeper exploration of the solution space
- Great for finding non-obvious innovations

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/hundred-to-ten-filter)*

---

# Idea Wizard

Generate and evaluate improvement ideas for a project, feature, or codebase.

## What This Does

Structured brainstorming and evaluation process:
1. Generate 30 ideas considering robustness, performance, UX, reliability
2. Evaluate each idea on implementation effort, user impact, complexity tradeoff
3. Winnow to top 5, ordered best to worst
4. Explain rationale for each top idea
5. Optionally implement the top idea

## How to Use

- **General improvements:** `/idea-wizard`
- **Specific focus:** `/idea-wizard <topic>` (e.g., "performance", "UX", "security")
- **For a feature:** `/idea-wizard "how to improve checkout flow"`

## Instructions

When this skill is invoked:

### Step 1: Generate 30 Ideas (Divergent Thinking)

Brainstorm 30 distinct ideas across these categories:
- **Robustness:** Error handling, resilience, fault tolerance
- **Performance:** Speed, efficiency, scalability
- **User Experience:** Usability, accessibility, delight
- **Reliability:** Testing, monitoring, observability
- **Security:** Auth, data protection, vulnerability fixes
- **Maintainability:** Code quality, documentation, architecture
- **Features:** New capabilities, enhancements, integrations

Don't filter yet — quantity over quality in this phase.

### Step 2: Evaluate Each Idea

For each of the 30 ideas, score on:
- **Implementation Effort:** 1 (trivial) to 5 (major)
- **User Impact:** 1 (negligible) to 5 (transformative)
- **Complexity Tradeoff:** Does benefit justify added complexity?

Calculate a rough priority score: `Impact / Effort`

### Step 3: Winnow to Top 5

Sort by priority score and select top 5, considering:
- Highest impact-to-effort ratio
- Strategic alignment with project goals
- Balance across different categories
- Feasibility with current resources

Order best to worst.

### Step 4: Explain Rationale

For each of the top 5, provide:
- **What:** Brief description of the idea
- **Why:** Expected benefit and impact
- **How:** High-level implementation approach
- **Tradeoffs:** What are we giving up or complicating?
- **Effort estimate:** Hours/days/weeks

### Step 5: Offer to Implement

Ask user if they want to:
1. Implement the top idea now
2. Create a plan for multiple ideas
3. Export ideas to a project roadmap
4. Generate more ideas in a specific category

## Example Output

```
=== Idea Wizard: Improving Checkout Flow ===

Generated 30 ideas, evaluated, top 5 below:

1. **Add one-click checkout for returning customers**
   Why: 80% of customers are repeat users, reduce friction from 5 clicks to 1
   How: Store payment method + shipping, show "Buy Now" button
   Tradeoffs: Slightly more complex auth flow, need PCI compliance review
   Effort: 2 days
   Impact: 5/5 (could increase conversion 15-20%)

2. **Implement optimistic UI updates**
   Why: Checkout feels slow, users abandon during loading states
   How: Update UI immediately, rollback on error
   Tradeoffs: More complex error handling, need idempotency
   Effort: 1 day
   Impact: 4/5 (better perceived performance)

3. **Add cart abandonment email recovery**
   Why: 70% cart abandonment rate, recover 10-15% with email
   How: Queue job on cart update, send email after 1 hour
   Tradeoffs: Email infrastructure, unsubscribe management
   Effort: 3 days
   Impact: 4/5 (direct revenue increase)

4. **Show real-time inventory on product pages**
   Why: Users add to cart then find out item is out of stock
   How: WebSocket connection for live inventory updates
   Tradeoffs: More server load, caching complexity
   Effort: 2 days
   Impact: 3/5 (reduces frustration, fewer abandoned carts)

5. **Add guest checkout option**
   Why: 30% of users abandon when forced to create account
   How: Allow purchase without account, optionally create after
   Tradeoffs: Need to handle anonymous users, order tracking
   Effort: 2 days
   Impact: 3/5 (removes friction, increases conversion)

Should I implement #1 now, create a plan for multiple, or explore more ideas?
```

## Related Skills

- **/plan-review** — Review implementation plans for ideas
- **/prd** — Turn ideas into structured Product Requirements Documents

---

# Multi-Model Synthesis

I asked 3 competing LLMs to do the exact same thing and they came up with pretty different plans which you can read below. I want you to REALLY carefully analyze their plans with an open mind and be intellectually honest about what they did that's better than your plan. Then I want you to come up with the best possible revisions to your plan (you should simply update your existing document for your original plan with the revisions) that artfully and skillfully blends the "best of all worlds" to create a true, ultimate, superior hybrid version of the plan that best achieves our stated goals and will work the best in real-world practice to solve the problems we are facing and our overarching goals while ensuring the extreme success of the enterprise as best as possible; you should provide me with a complete series of git-diff style changes to your original plan to turn it into the new, enhanced, much longer and detailed plan that integrates the best of all the plans with every good idea included (you don't need to mention which ideas came from which models in the final revised enhanced plan).

## When to Use

- When you have outputs from multiple LLMs on the same task
- For important architectural decisions
- When you want the best possible plan regardless of source

## Tips

- Works with Claude, GPT, Gemini, or any combination
- Requires intellectual honesty about other models' strengths
- Great for avoiding single-model blind spots

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/multi-model-synthesis)*

---

# The Next Best Move

## Instructions

When this skill is invoked:

### Step 1: Ground Yourself in the Project

Before thinking, read the project context:

1. Look for and read `AGENTS.md` if it exists — this describes how the project works, its conventions, and agent roles
2. Look for and read the project plan — check for `PLAN.md`, `prd.json`, `PRD.md`, `TODO.md`, `ROADMAP.md`, or any similarly named planning document in the project root
3. Briefly scan the codebase structure if needed to understand where things stand

### Step 2: Ultrathink

Use your extended thinking capacity (ultrathink) to deeply consider the project from every angle:

- What is the project actually trying to accomplish?
- What's been built so far vs. what's planned?
- Where are the biggest gaps, bottlenecks, or missed opportunities?
- What would create disproportionate value — technically, strategically, for users?
- What's the one thing that, if added now, would make everything else more effective?

Think across dimensions: architecture, UX, developer experience, business value, technical leverage, emergent capabilities, compounding effects.

### Step 3: Answer the Question

What's the single smartest and most radically innovative, accretive, useful, and compelling addition you could make to the plan or project at this point?

Present your answer as:

**The Idea:** One clear sentence.

**Why This, Why Now:** The specific reasoning — what makes this the single best move given the current state of the project, not just a good idea in the abstract.

**What It Unlocks:** Second-order effects. What becomes possible or easier because of this addition?

**How to Do It:** A concise implementation sketch — just enough to make it actionable.

**What You'd Trade Off:** Be honest about what gets deprioritized or complicated by choosing this.

## When to Use

- When you're not sure what to work on next
- After completing a milestone and deciding where to go from here
- When the current plan feels stale or incremental and you want a sharper direction
- Before a planning session to prime your thinking

## Tips

- The answer is rarely "add more features" — it's often architectural, strategic, or about compounding leverage
- The best moves often feel slightly uncomfortable or audacious
- If the answer is obvious, you haven't thought hard enough

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/next-best-move)*

---

# Random Code Exploration and Bug Hunt

Randomly explore source files in this project, deeply investigate their functionality and execution flows, then find and fix bugs with fresh eyes. Be systematic, methodical, and critical. Use ultrathink.

Comply with ALL rules in AGENTS.md. Ensure any code you write or revise conforms to the best practice guides referenced in AGENTS.md.

## Exploration Strategy

### 1. Discover files to explore

Use `./robot files` if available — it finds source files appropriate for this project automatically:

```bash
# Preferred:
./robot files --json

# Fallback — find source files in the directories AGENTS.md describes:
# Check AGENTS.md Project Structure section for the right directories,
# then list files within them. Do NOT assume src/, app/, or any specific path.
```

Pick 3–5 files at random to start, spread across different areas.

### 2. For each file

- Read it completely
- Trace imports or includes upstream — understand what it depends on
- Trace exports or usages downstream — understand what depends on it
- Map the full data and control flow
- Understand the file's purpose in the larger application context

### 3. Apply fresh-eyes inspection

Look for:
- Logic errors and off-by-one mistakes
- Unreachable branches or dead code
- Missing null/undefined/empty checks
- Incorrect assumptions about data shape
- Hardcoded values that should be configurable
- Missing error handling or graceful degradation
- Security issues (XSS, injection, exposed secrets)
- Accessibility violations (missing labels, focus traps, contrast)
- Performance issues (unnecessary re-renders, blocking operations, N+1 patterns)
- TODO/FIXME comments that were never addressed
- Violations of AGENTS.md rules or project conventions

### 4. Fix what you find

Fix issues directly and carefully. Do not introduce new patterns — match existing conventions in the codebase. For each fix, understand the root cause first.

### 5. Verify with project check commands

After fixes, run the check commands from AGENTS.md's Quick Reference (build, typecheck, lint — whatever applies to this project). Fix any errors. Repeat until clean.

### 6. Report and continue

After fixing, notify fellow agents via MCP Agent Mail of what you found and fixed. Then pick another set of files and repeat.

---

## When to Use

- When agents are idle between tasks
- As a general code quality sweep
- When lurking bugs are suspected

## Tips

- Spread coverage — don't re-explore files you've already reviewed this session
- Fixes should always be committed via the git manager
- Great for keeping agents productively busy between bead tasks

---

# Commit All Changes

Commit all changed files in logically connected groupings with detailed commit messages. Do not edit any code. Do not commit ephemeral files. Use ultrathink.

## Process

### 1. Review all changes

```bash
git status
git diff
```

### 2. Sync beads before committing

Always flush the beads database and stage `.beads/` so code and tracking stay in sync:

```bash
# Preferred:
./robot sync

# Fallback:
br sync --flush-only
git add .beads/
```

### 3. Group changes logically

Group by:
- Feature or component
- Commit type (feat, fix, chore, docs, test)
- Related functionality that belongs together

### 4. Commit each group

Stage specific files — never `git add -A` blindly:

```bash
git add <specific-files>
git commit -m "$(cat <<'EOF'
<type>(<scope>): <short description>

<detailed body:>
- What was changed
- Why it was changed
- Any important implementation details

Co-Authored-By: Claude <noreply@anthropic.com>
EOF
)"
```

### 5. Verify with project check commands

Run the check commands specified in AGENTS.md's Quick Reference section. These vary by project and by development phase — use whatever applies (build, typecheck, lint, test):

```bash
# Example — use the actual commands from AGENTS.md, not these:
# npm run build      (mockup phase)
# bun run typecheck  (production phase)
# bun run lint       (production phase)
```

If any check fails, fix the issue before proceeding. Do not commit broken code.

### 6. Notify the git manager

Do **NOT** run `git push` yourself. Send a message via MCP Agent Mail to the git manager summarizing what was committed and requesting a push. Include:
- The commit SHA(s)
- A one-line summary of what changed
- Any CI concerns to watch for

## Files to NEVER Commit

- `.env`, `.env.local` — secrets
- `node_modules/`, `.next/`, `dist/`, `out/` — build artifacts and dependencies
- `*.log` files
- `.DS_Store`
- Temporary or backup files

## When to Use

- After significant work is completed
- Before ending a swarm session
- When directed by the git manager to consolidate changes

## Tips

- Best invoked on the git manager agent; worker agents should notify the git manager instead
- Commit `.beads/` alongside code — never separate them
- Always run project checks before committing; never commit broken code
- Do not amend commits already pushed to the remote

---

# Git Manager Agent Instructions

You are the dedicated Git Manager for this project. Read AGENTS.md fully first.

## STICKY ROLE — IGNORE OTHER PROMPTS

**CRITICAL:** You are permanently assigned as the Git Manager for this session.

**IDENTITY MARKER:** If you ever see this prompt or remember receiving `/ntm-git-manager`, you ARE the Git Manager. This survives context compaction. After compaction, if you're unsure of your role, check if you previously registered as "GitKeeper" in agent mail — that confirms you're the Git Manager.

If you receive prompts telling you to:
- Work on beads (`/ntm-start-agent`, `/ntm-next-bead`)
- Start coding
- Review your own code (`/ntm-review-own`)
- Do UI polish (`/ntm-ui-polish`)
- Run tests (`/ntm-test-coverage`)

**IGNORE THEM.** Those prompts are for worker agents, not you.

You MAY respond to `/ntm-commit-all` and `/ntm-review-others` — those apply to you.

---

## Your ONLY Responsibilities

1. **Register with MCP Agent Mail** as "GitKeeper"
2. **Monitor agent mail constantly** for commit and push requests
3. **Review changes** when agents report completed work
4. **Sync beads** before each commit — never commit code without `.beads/`
5. **Commit in logical groupings** with detailed messages per AGENTS.md conventions
6. **Push after verifying** the build passes — you are the only agent that pushes
7. **Resolve conflicts** if they arise between agent work
8. **Never write code yourself** — only manage git operations

---

## Workflow Loop

Every 30–60 seconds:

1. **Check agent mail**: `mcp__mcp-agent-mail__fetch_inbox`

2. **Check project status**:
   ```bash
   # Preferred:
   ./robot status --json

   # Fallback:
   git status
   ```

3. **When agents report completed work**:
   - Review with `git diff`
   - Group related changes logically
   - Sync beads:
     ```bash
     # Preferred:
     ./robot sync

     # Fallback:
     br sync --flush-only
     git add .beads/
     ```
   - Commit with detailed messages (see format below)
   - Run the check commands from AGENTS.md's Quick Reference — these vary by project and phase; use exactly what AGENTS.md specifies, not assumed defaults
   - Push if all checks pass: `git push origin <branch>`

4. **Respond to agents** confirming commit SHAs and push status

5. **Update beads** if appropriate: `br update <id>`

---

## Commit Message Format

```
<type>(<scope>): <description>

<body with details>

Co-Authored-By: Claude <noreply@anthropic.com>
```

---

## Important Rules

- NEVER skip pre-commit hooks (`--no-verify` is forbidden)
- NEVER force push to main or any shared branch
- NEVER amend commits that other agents may have built on
- ALWAYS verify the build passes before pushing
- ALWAYS commit `.beads/` alongside code — never one without the other
- ALWAYS communicate commit and push status back to requesting agents

Use ultrathink.

---

## When to Use

- At the start of a swarm session — assign to one dedicated pane only
- This agent becomes the sole git coordinator for the session
- All other agents must request commits through this agent; they do NOT push themselves

## Tips

- Only one git manager per swarm session — do not spawn multiples
- This role is sticky — survives context compaction via "GitKeeper" registration
- If you lose context, re-read AGENTS.md and check agent mail to reconstruct state

---

# Continue to Next Bead

Reread AGENTS.md so it's still fresh in your mind. Use ultrathink.

Find the most impactful bead to work on next, claim it, and start immediately.

## Step 1: Find Next Task

Use `./robot next` if available, otherwise fall back to `bv --robot-next` directly:

```bash
# Preferred:
./robot next --json

# Fallback:
bv --robot-next
```

## Step 2: Claim and Announce

```bash
# Preferred:
./robot claim <id>

# Fallback:
br update <id> --status in_progress
```

Notify fellow agents via MCP Agent Mail what you're starting. Check for any pending messages and respond before diving in.

## Step 3: Implement

Work systematically and meticulously. Follow AGENTS.md rules at every step. Comply with the best practice guides referenced in AGENTS.md.

## Step 4: Self-Review

Before closing, run `/ntm-review-own` to catch issues with fresh eyes.

## Step 5: Close and Sync

```bash
# Preferred (closes bead + flushes .beads/):
./robot done <id>

# Fallback:
br close <id> --reason "Description of what was done"
br sync --flush-only
git add .beads/
```

Then commit your code and `.beads/` changes together, and notify the git manager.

## Step 6: Loop

Run `/ntm-next-bead` again to pick up the next task.

---

## When to Use

- After an agent completes a task
- When agents are idle and need direction
- To keep the swarm productive

## Tips

- Always claim before starting to prevent duplicate work by other agents
- Communicate via MCP Agent Mail to stay coordinated
- Do NOT push — notify the git manager after committing

---

# Project Preparation

Before touching a single line of code or claiming any task, complete every step below in full. No shortcuts. Use ultrathink throughout.

---

## Step 0: Ensure `./robot` CLI Exists

Check for the project-level agent CLI before anything else:

```bash
ls ./robot 2>/dev/null && echo "exists" || echo "missing"
```

If missing, invoke `/robot-mode-maker` to create it. The `./robot` CLI provides machine-readable status, file discovery, bead operations, and build execution — later steps depend on it.

---

## Step 1: Read AGENTS.md — Cover to Cover

Read the **entire** `AGENTS.md` file. Do not skim. Internalize every section.

Pay special attention to:

1. **Rule Number 1** — NEVER delete any file without express written permission. This is absolute.
2. **Irreversible Git & Filesystem Actions** — Forbidden commands, safer alternatives, mandatory explicit plan.
3. **Tech Stack** — Framework versions, package manager, deployment target. Note exactly what AGENTS.md specifies — do not assume bun, npm, or any particular framework.
4. **Code Editing Discipline** — No code-mod scripts. No mass regex. Mechanical changes via parallel subagents only.
5. **File Organization** — No duplicate or versioned files. No `componentV2`, no shims. Revise existing files in place.
6. **Design System** — Color palette, typography, and any motion or accessibility guidelines specific to this project.
7. **Static Analysis** — Note the exact check commands in AGENTS.md's Quick Reference. These vary by project and by development phase — do not assume `bun`, `npm`, or specific command names.
8. **Issue Tracking** — ALL task tracking goes through `br`. Never use markdown TODOs.
9. **Automatic Skill Triggers** — If a trigger table exists, memorize it. You MUST invoke triggered skills automatically.
10. **Workflow Loop** — Follow the triage → claim → implement → review → close → next loop exactly.
11. **Git Workflow** — Commit code AND `.beads/` together. Do NOT run `git push` yourself — notify the git manager.
12. **Agent Communication** — Register with MCP Agent Mail. Check inbox. Notify peers of what you're working on.

---

## Step 2: Read README.md — Cover to Cover

Read the **entire** `README.md`. Understand:

- What the project is and who it's for
- Product goals and target audience
- Setup, configuration, or deployment instructions
- Key features and how they fit together
- Any conventions, gotchas, or important notes

---

## Step 3: Get Project Health Snapshot

```bash
./robot status --json
```

Note: current git branch, uncommitted files, bead counts (open/actionable/in-progress), and scaffold state. This tells you exactly where the project stands before you explore code.

---

## Step 4: Investigate the Codebase

Use your Explore agent subagent mode. **Base your exploration entirely on what AGENTS.md describes as the project structure** — do not assume Next.js, Rails, HTML, or any particular layout. Read the directories and files that AGENTS.md points to.

### 4a. Project Structure
- Scan the top-level directory layout
- Map each major directory to the role AGENTS.md describes for it
- Note anything unusual, missing, or not yet scaffolded

### 4b. Entry Points
- Find the main entry points for the project (could be HTML files, app entry files, API routes, index files — whatever this project uses)
- Understand how the application starts and how pages or routes are organized

### 4c. Design System & Tokens
- Find the primary styling files (CSS, design token files, theme configs)
- Understand the color palette, spacing, and any utility or token conventions
- Note the design values from AGENTS.md Brand Colors section

### 4d. Shared Components / Templates
- Explore shared layout components, templates, or partials described in AGENTS.md
- Read navigation, header, footer, and any layout wrappers
- Understand shared UI primitives or component patterns

### 4e. Data & Business Logic
- Find seed data, fixtures, content files, or API schemas
- Read key utility or shared library files
- Understand data shapes and how they flow through the application

### 4f. Build & Configuration
- Read build config files referenced in AGENTS.md (package.json, vite.config, next.config, etc.)
- Understand the dev/build/preview/test commands — these are your check commands
- Note environment variables or configuration requirements

### 4g. Tests (if present)
- Check whether a test directory exists
- Understand what's covered and what tooling is used
- If no tests exist, note that for later

---

## Step 5: Synthesize & Confirm Readiness

Internally summarize before picking up any work:

- The project's purpose and key technical decisions
- Rules you must never violate: Rule #1 (no deletion), correct package manager, `br` for tracking, no self-push
- The exact check commands for this project (from AGENTS.md Quick Reference)
- Whether `./robot` exists and what commands it exposes (`./robot help --json`)
- Current bead state: `./robot triage --json` (or `bv --robot-triage` as fallback)

Only then are you ready to claim a task and begin work.

---

## When to Use

- At the very start of a fresh agent session
- When onboarding a new agent to the swarm for the first time
- Whenever an agent feels uncertain about project conventions or architecture
- After a long break or major architectural change

## Tips

- Use ultrathink throughout — this prep pays dividends for the entire session
- Do NOT rush Step 4. A thorough investigation prevents mistakes that are expensive to fix
- AGENTS.md is the authoritative source; if README.md conflicts with it, AGENTS.md wins
- If you find something undocumented or surprising, note it before continuing
- This skill supersedes `ntm-start-agent` for initial orientation

---

# Refresh Context

Reread AGENTS.md so it's still fresh in your mind. Use ultrathink.

Pay special attention to:
- Rule Number 1 (NEVER delete files without permission)
- Git workflow and commit conventions — do NOT push yourself; notify the git manager
- Package manager and check commands — note what AGENTS.md specifies, do not assume
- Code editing discipline
- Issue tracking with br (beads_rust)
- Agent communication protocol
- Any active development phase restrictions

## Identity Recovery Protocol

After context compaction, you need to recover your agent identity. The compaction summary contains your session UUID in the transcript path.

### Step 1: Extract Session UUID from Compaction Summary

Look for this line in the compaction summary message:
> "read the full transcript at: /home/.../.claude/projects/-<project-slug>/<SESSION_UUID>.jsonl"

Extract the UUID (the filename without `.jsonl`).

### Step 2: Look Up Your Identity

```bash
# Get project directory
PROJECT_DIR=$(pwd)
PROJECT_HASH=$(echo -n "$PROJECT_DIR" | md5sum | cut -c1-12)

# Use the SESSION_UUID from the compaction summary
IDENTITY_FILE="$HOME/.claude/agent-identities/$PROJECT_HASH/<SESSION_UUID>.json"

if [ -f "$IDENTITY_FILE" ]; then
    cat "$IDENTITY_FILE"
    AGENT_NAME=$(jq -r '.agent_name' "$IDENTITY_FILE")
else
    echo "WARNING: No identity file found. You may need to register as a new agent."
fi
```

### Step 3: Reconnect with MCP Agent Mail

Call `macro_start_session` with your recovered identity:

```
mcp__mcp-agent-mail__macro_start_session
  human_key: "<PROJECT_DIR>"
  agent_name: "<AGENT_NAME from identity file>"
  agent_role: "<ROLE from identity file>"
```

If the identity file doesn't exist, you'll need to generate a new identity (omit `agent_name` to auto-generate), then **save it for future recovery**:

```bash
# After macro_start_session returns your new agent name:
mkdir -p "$HOME/.claude/agent-identities/$PROJECT_HASH"
cat > "$HOME/.claude/agent-identities/$PROJECT_HASH/$SESSION_UUID.json" << EOF
{
  "agent_name": "<YOUR_NEW_AGENT_NAME>",
  "role": "<YOUR_ROLE>",
  "project_key": "$(pwd)",
  "created_at": "$(date -Iseconds)"
}
EOF
echo "Identity saved for future compaction recovery"
```

## Post-Recovery Checklist

After recovering your identity:

1. **Check your agent mail inbox** for any messages you may have missed
2. **Run `./robot status --json`** for current project health (or `bv --robot-next` as fallback)
3. **Run `br ready`** to see available tasks
4. **Review your in-progress work** — check if you had any beads claimed before compaction

Then proceed with your current task or pick a new one.

## When to Use

- After context compaction (when agent memory is compressed)
- When agent seems to have forgotten project rules
- Periodically to reinforce key conventions
- When the compaction summary mentions a transcript path

## Tips

- Critical after long sessions
- Prevents rule violations from context loss
- Keeps agents aligned with project standards
- Identity files are stored in `~/.claude/agent-identities/<project-hash>/`
- If identity recovery fails, register fresh and notify the swarm of your new name

---

# Cross-Agent Code Review

Review code written by your fellow agents. Check for bugs, errors, inefficiencies, security problems, and reliability issues. Diagnose root causes using first-principles analysis. Fix or revise where necessary.

Don't restrict yourself to the latest commits — cast a wide net and go deep. Use ultrathink.

## Review Process

### 1. Survey recent agent work

```bash
git log --oneline -20
```

For each commit from other agents:
- `git show <sha>` to see the full diff
- Trace the code paths affected
- Look for integration issues with your own work
- Check for violations of AGENTS.md rules or project conventions

### 2. Go deeper where warranted

Use `./robot files [query]` (or explore the directories described in AGENTS.md) to find related files that might be affected by the changes. Don't limit review to just the diff — understand the full impact radius.

### 3. Common issues to watch for

- Inconsistent patterns across files (different agents solving the same problem differently)
- Broken or missing imports after refactoring
- Duplicate code that should be in a shared location
- Race conditions in async code
- Missing error boundaries or graceful degradation
- Memory leaks in effects, subscriptions, or event listeners
- Security vulnerabilities introduced by new code
- AGENTS.md rule violations (wrong package manager commands, attempted file deletion, etc.)
- Hardcoded values that should reference project design tokens or config

### 4. Fix what you find

Fix issues directly. Understand the root cause before patching the symptom. Match existing project conventions — do not introduce new patterns.

### 5. Run full verification

Run the check commands from AGENTS.md's Quick Reference (build, typecheck, lint, test — whatever applies to this project). Fix all errors before committing your review fixes.

```bash
# Use whatever AGENTS.md specifies, for example:
# ./robot build       (if ./robot is available)
# npm run build       (mockup phase)
# bun run typecheck && bun run lint  (production phase)
```

### 6. Notify original agents

Via MCP Agent Mail, inform the agent whose code you modified what you found and why you changed it. This keeps the swarm aligned and prevents agents from redoing work in conflicting ways.

---

## When to Use

- Periodically during swarm sessions (every few beads)
- When multiple agents have been working in parallel
- Before major commits or releases
- When integration issues are suspected

## Tips

- Catches issues that self-review misses — especially cross-agent consistency
- Always notify the original agent; don't silently rewrite their work
- Commit review fixes via the git manager like any other code change

---

# Review Your Own Code

Read over all of the new code you just wrote and all existing code you just modified with fresh eyes. Look carefully for any obvious bugs, errors, problems, issues, or confusion. Fix anything you uncover. Use ultrathink.

## What to Check

- Logic errors and off-by-one mistakes
- Null/undefined/empty handling
- Error handling gaps — what happens on failure?
- Type mismatches or incorrect assumptions about data shape
- Missing edge cases
- Security vulnerabilities (XSS, injection, exposed values, etc.)
- Performance issues (blocking operations, unnecessary work, N+1 patterns)
- Accessibility problems (missing labels, keyboard traps, color contrast)
- Compliance with all rules in AGENTS.md
- Conformance to best practice guides referenced in AGENTS.md

## After Fixing Issues

Run the check commands from AGENTS.md's Quick Reference section. These vary by project and phase — use the exact commands specified there, not any assumed default:

```bash
# Use whatever AGENTS.md specifies, for example:
# ./robot build       (if ./robot is available)
# npm run build       (mockup phase)
# bun run typecheck   (production phase)
# bun run lint        (production phase)
```

Fix any errors that appear. Repeat until clean.

## When to Use

- After completing a bead — this is a required quality gate before closing
- Before handing off work to the git manager
- Whenever you feel uncertain about something you just wrote

## Tips

- Read the code as if someone else wrote it — suspend authorial familiarity
- Pay extra attention to the first and last lines of functions — edge cases cluster there
- If a check command doesn't exist yet (e.g., scaffold not built), note it and move on

---

# Agent Startup Instructions

Read ALL of AGENTS.md super carefully before doing anything else. Pay special attention to:

1. **Rule Number 1** — NEVER delete files without explicit permission
2. **Automatic Skill Triggers** — You MUST follow these triggers automatically
3. **Git Workflow** — Do NOT push yourself; notify the git manager after committing
4. **Tech Stack & Check Commands** — Note the exact commands for this project; do not assume

Then use your code investigation agent mode to understand the codebase architecture.

## Required Setup

1. **Check for `./robot`** — if it doesn't exist, run `/robot-mode-maker` first
2. **Get project health snapshot**: `./robot status --json` (or `bv --robot-triage` fallback)
3. **Establish your agent identity** using the Session Identity Protocol below
4. **Check your inbox** and respond to any pending messages

## Session Identity Protocol

Agent identities must persist across context compactions. Follow this protocol:

### Step 1: Determine Your Session UUID

```bash
# Get the project directory from pwd or AGENTS.md
PROJECT_DIR=$(pwd)

# Find the Claude projects directory for this project
# Replace / with - to match Claude's directory naming
PROJECT_SLUG=$(echo "$PROJECT_DIR" | sed 's|^/||; s|/|-|g')
CLAUDE_PROJECT_DIR="$HOME/.claude/projects/-$PROJECT_SLUG"

# Get your session UUID (most recently modified transcript)
SESSION_UUID=$(basename "$(ls -t "$CLAUDE_PROJECT_DIR"/*.jsonl 2>/dev/null | head -1)" .jsonl)
echo "Session UUID: $SESSION_UUID"
```

### Step 2: Check for Existing Identity

```bash
# Create project hash for identity directory
PROJECT_HASH=$(echo -n "$PROJECT_DIR" | md5sum | cut -c1-12)
IDENTITY_DIR="$HOME/.claude/agent-identities/$PROJECT_HASH"
IDENTITY_FILE="$IDENTITY_DIR/$SESSION_UUID.json"

# Check if identity exists
if [ -f "$IDENTITY_FILE" ]; then
    echo "Found existing identity:"
    cat "$IDENTITY_FILE"
    AGENT_NAME=$(jq -r '.agent_name' "$IDENTITY_FILE")
else
    echo "No existing identity for this session"
    AGENT_NAME=""
fi
```

### Step 3: Register with MCP Agent Mail

Call `macro_start_session` with the project's `human_key` (the absolute project path):

- **If identity file exists:** Use the `agent_name` from the file
- **If no identity file:** Omit `agent_name` to auto-generate one

```
mcp__mcp-agent-mail__macro_start_session
  human_key: "<PROJECT_DIR>"
  agent_name: "<AGENT_NAME or omit>"
  agent_role: "Brief description of your role"
```

### Step 4: Save Your Identity

After successful registration, save your identity for recovery after compaction:

```bash
mkdir -p "$IDENTITY_DIR"
cat > "$IDENTITY_FILE" << EOF
{
  "agent_name": "<YOUR_AGENT_NAME>",
  "role": "<YOUR_ROLE>",
  "project_key": "$PROJECT_DIR",
  "created_at": "$(date -Iseconds)"
}
EOF
```

## Starting Work

1. Find priority work: `./robot next --json` (or `bv --robot-next`)
2. Claim the bead: `./robot claim <id>` (or `br update <id> --status in_progress`)
3. Notify agents via MCP Agent Mail what you're working on
4. Implement the task systematically — comply with AGENTS.md and best practice guides
5. Before closing: run `/ntm-review-own` to catch bugs with fresh eyes
6. Close and sync: `./robot done <id>` (or `br close <id>` + `br sync --flush-only`)
7. Commit code and `.beads/` together; notify the git manager — do NOT push yourself
8. Loop: run `/ntm-next-bead`

Don't get stuck in "communication purgatory" — be proactive about starting tasks, but always mark beads and inform fellow agents.

Use ultrathink.

## Required Tools

- **MCP Agent Mail** — inter-agent coordination
- **`./robot`** — standardized project operations (status, next, claim, done, build, files)
- **`bv`** (beads_viewer) — priority-based task selection (fallback if `./robot` unavailable)
- **`br`** (beads_rust) — issue and task tracking

## When to Use

- At the start of a new worker agent session
- When spawning worker agents in an NTM swarm
- To get agents oriented and productive quickly

## Tips

- Send to worker agents only — not the git manager (use `/ntm-git-manager` for that)
- Always claim beads before starting to prevent duplicate work
- All coordination happens through MCP Agent Mail
- Identity files are stored globally in `~/.claude/agent-identities/` to survive fresh clones

---

# Test Coverage Audit

Test coverage is not optional and cannot be half-assed. Comprehensive, real tests are a mark of professional craftsmanship and deep respect for the codebase, the team, and the users who depend on this software. We take our work seriously. Half-assing is not acceptable.

If we don't have full test coverage, create a comprehensive and granular set of beads for all missing areas with tasks, subtasks, and dependency structure overlaid with detailed comments.

**Prefer real implementations over mocks.** Tests that mock everything prove nothing.

Use ultrathink.

## Step 1: Discover the Test Setup

Check AGENTS.md and the project's package config to identify:
- Unit test framework and runner (Vitest, Jest, pytest, Go test, etc.)
- Integration/E2E test framework (Playwright, Cypress, etc.)
- Any API or backend test tooling (Miniflare, Supertest, etc.)
- Existing test directories and conventions

```bash
./robot files test --json   # if ./robot is available
```

## Step 2: Audit Coverage

Work through each category below. **Skip a category only if it genuinely does not apply to this project's architecture** — and when you skip, document why. Never skip out of laziness or time pressure.

### Unit Tests
- [ ] All utility and helper functions
- [ ] All form validation logic
- [ ] All data transformation and parsing logic
- [ ] Business logic and domain rules
- [ ] Content or data collection transforms (if applicable)
- [ ] Search query parsing (if applicable)
- [ ] Animation variant or UI state logic (if applicable)
- [ ] Edge cases and error paths for all of the above

### Component / UI Tests
*(Skip only if project has no UI components)*
- [ ] All UI components render correctly with varied props
- [ ] Props and configuration handled properly
- [ ] Accessibility attributes present (labels, ARIA roles, focus management)
- [ ] Error states displayed correctly
- [ ] Empty and loading states handled
- [ ] User interactions behave as expected

### E2E / Integration Tests
*(Skip only if project has no browser-facing interface)*
- [ ] Full navigation flow
- [ ] Form submissions (with and without JavaScript)
- [ ] Search functionality (if applicable)
- [ ] Critical user journeys end-to-end
- [ ] Authentication flows (if any)
- [ ] Mobile viewport testing

### API / Backend Tests
*(Skip only if project has no backend or API layer)*
- [ ] All API endpoints return correct responses
- [ ] Authentication and authorization enforced
- [ ] Error responses have correct status codes and response bodies
- [ ] Rate limiting behavior (if applicable)
- [ ] Queue processing and async operations (if applicable)
- [ ] Database operations and edge cases (if applicable)

## Step 3: Create Beads for Gaps

For each area with missing coverage, create a bead:

```bash
br create "Tests: <specific area>" --type task --priority 2
```

Include in each bead description:
- Specific functions, components, or flows to test
- Edge cases to cover
- Expected logging format
- Acceptance criteria (what "done" looks like)

## When to Use

- Before major releases
- When coverage feels incomplete
- After significant new features
- When a bug is found that a test should have caught — that gap must be closed

## Tips

- Prefer real implementations over mocks — test actual behavior, not your assumptions about it
- Include detailed logging for easier debugging when tests fail
- Group test beads under a parent test-coverage epic for organization
- Check AGENTS.md for any project-specific testing conventions or CI requirements

---

# UI/UX Polish Pass

Enhance the UI/UX look and feel to make everything more intuitive, user-friendly, visually appealing, polished, and world-class — following the best practices of top-tier products like Stripe, Linear, and Vercel.

Consider desktop and mobile separately. Hyper-optimize for both modalities. Use ultrathink.

I'm looking for true world-class visual appeal, polish, slickness, etc. that makes people gasp at how stunning and perfect it is in every way.

**Before starting:** Read AGENTS.md to understand the design system for this project — color palette, typography, spacing tokens, and any brand guidelines. Apply those values throughout; do not invent new ones.

## Areas to Focus

### Visual Polish
- Consistent spacing and alignment across all elements
- Smooth transitions and animations (always respect `prefers-reduced-motion`)
- Proper color contrast (WCAG AA minimum; AA for body text, AA for UI elements)
- Typography hierarchy and vertical rhythm
- Subtle shadows and depth cues
- Appropriate use of brand colors and accent tones per AGENTS.md

### Desktop Optimizations
- Hover states on all interactive elements
- Keyboard navigation completeness and visible focus rings
- Wide viewport layouts that use space efficiently
- Multi-column layouts where content warrants it
- Command palette or keyboard shortcut integration where appropriate

### Mobile Optimizations
- Touch targets minimum 44×44px
- Thumb-friendly placement of primary actions
- Swipe gestures where intuitive
- No functionality that requires hover
- Fast tap response (eliminate 300ms delay)
- Appropriate viewport scaling and safe area insets

### Micro-interactions
- Button and control press feedback
- Loading and skeleton states
- Success/error confirmation animations
- Scroll-triggered reveals (with reduced-motion fallback)
- Focus ring transitions

## When to Use

- After core features are implemented
- For final polish before stakeholder review or release
- When the UI is functional but not yet delightful

## Tips

- Work one area at a time — polish breadth-first before depth
- Test on both desktop and mobile viewports before closing
- Never override AGENTS.md brand colors with invented ones
- Respect accessibility requirements — polish should never reduce usability

---

# Unstall the Queue

Find beads stuck `in_progress` with no recent activity (abandoned by dead agents), reset them to `open`, then pick up the highest-impact available work.

## Step 1: Check Agent Mail First

**Before resetting anything**, check your inbox to confirm no live agent is actively working the beads you're about to reset. Resetting a bead under an active agent causes conflicts:

```
mcp__mcp-agent-mail__fetch_inbox
```

If another agent is clearly working on a bead, do not reset it — coordinate with them instead.

## Step 2: Find Stalled Beads

```bash
br list --status in_progress --json
```

A bead is stalled if:
- It has been `in_progress` for a long time with no corresponding commits or activity in `git log`
- The agent that claimed it is no longer reachable via agent mail
- No recent progress notes or updates exist on the bead

## Step 3: Reset Stalled Beads to Open

For each confirmed stalled bead:

```bash
br update <id> --status open
br update <id> --reason "Reset from in_progress: no agent activity detected, returning to queue"
```

## Step 4: Notify the Swarm

Via MCP Agent Mail, send a brief message:

> "Recovered N stalled bead(s): [list IDs]. Back in the open queue. Picking up [highest-priority ID] now."

## Step 5: Find the Highest-Impact Work

```bash
# Preferred:
./robot triage --json

# Fallback:
bv --robot-next
bv --robot-plan
```

Check for cycles or critical path blockages if triage looks unusual:

```bash
bv --robot-insights
```

## Step 6: Claim and Begin

```bash
# Preferred:
./robot claim <id>

# Fallback:
br update <id> --status in_progress
```

Notify fellow agents what you're picking up, then implement.

---

## When to Use

- When `br ready` returns empty but `br list --status in_progress` shows beads
- When agents have died mid-task and left the queue blocked
- As a periodic health check on swarm queue state
- When overall velocity feels low despite agents being active

## Tips

- Always check agent mail before resetting — never reset a live agent's work
- After resetting, use `bv --robot-insights` to check for cycles or critical path blockages
- This is a good complement to `/ntm-next-bead` when the queue appears empty but isn't

---

# Peer Code Reviewer

Ok can you now turn your attention to reviewing the code written by your fellow agents and checking for any issues, bugs, errors, problems, inefficiencies, security problems, reliability issues, etc. and carefully diagnose their underlying root causes using first-principle analysis and then fix or revise them if necessary? Don't restrict yourself to the latest commits, cast a wider net and go super deep!

## When to Use

- After multiple agents have been working on a project
- Before merging parallel work streams
- For quality assurance in multi-agent workflows

## Tips

- Different from Bug Hunter - focuses on other agents' work
- Catches integration issues from parallel development
- Essential for multi-agent coordination

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/peer-code-reviewer)*

---

# Peer Review

Review code as a senior developer would — structured feedback on bugs, style, security, and performance.

## What This Does

Structured code review (like a senior engineer reviewing a PR) covering:
- **Bugs & Logic:** Correctness, edge cases, error handling
- **Security:** Vulnerabilities, data exposure, auth issues
- **Performance:** Efficiency, scalability, resource usage
- **Style & Maintainability:** Readability, patterns, documentation
- **Testing:** Test coverage, test quality

Output is structured feedback with severity levels and actionable suggestions.

## How to Use

- **Review recent changes:** `/peer-review` (reviews git diff)
- **Review specific files:** `/peer-review <file-paths>`
- **Review PR:** `/peer-review --pr <number>` (uses gh CLI)
- **Focus area:** `/peer-review --security` or `--performance`

## Instructions

When this skill is invoked:

### Step 1: Identify Code to Review

- **Default:** Run `git diff` to see recent changes
- **Specific files:** Read the specified file paths
- **PR mode:** Use `gh pr diff <number>` to get PR changes
- **Focus area:** If specified, prioritize that aspect in review

### Step 2: Review Each Aspect

#### A. Bugs & Logic
- Are there logical errors, off-by-one errors, race conditions?
- Are edge cases handled (empty arrays, null values, boundary conditions)?
- Is error handling comprehensive (try/catch, error returns)?
- Are assumptions validated (type checks, null checks)?

#### B. Security
- **Input validation:** All user input sanitized and validated?
- **SQL injection:** Using parameterized queries, not string concatenation?
- **XSS:** Output properly escaped for HTML context?
- **Auth/authz:** Proper authentication and authorization checks?
- **Data exposure:** Sensitive data (passwords, tokens) not logged or exposed?
- **CSRF:** State-changing operations protected?

#### C. Performance
- **Database:** N+1 queries? Missing indexes? Unnecessary queries?
- **Algorithms:** Efficient complexity (avoid O(n²) if possible)?
- **Caching:** Opportunities to cache expensive operations?
- **Memory:** Leaks, unbounded arrays, large object retention?
- **Network:** Unnecessary API calls, missing pagination?

#### D. Style & Maintainability
- **Readability:** Clear variable names, logical structure, appropriate comments?
- **Patterns:** Follows existing codebase patterns and conventions?
- **DRY:** Code duplication that should be extracted?
- **Complexity:** Functions too long or complex (>50 lines, >3 levels deep)?
- **Documentation:** Complex logic explained, public APIs documented?

#### E. Testing
- **Coverage:** Are critical paths tested?
- **Quality:** Tests actually verify behavior, not just pass?
- **Edge cases:** Tests cover error paths, edge cases, boundary conditions?
- **Maintainability:** Tests are clear, not brittle, easy to understand?

### Step 3: Categorize Findings

For each issue, assign severity:
- **BLOCKING:** Must fix before merge (security holes, crashes, data loss)
- **HIGH:** Should fix before merge (bugs, performance issues)
- **MEDIUM:** Fix soon (code smells, missing tests, minor inefficiencies)
- **LOW:** Consider fixing (style, documentation, nitpicks)

### Step 4: Provide Actionable Feedback

For each finding:
- **Location:** File and line number (e.g., `auth.ts:42`)
- **Issue:** What's wrong
- **Impact:** Why it matters
- **Suggestion:** How to fix it (with code example if helpful)

### Step 5: Summary & Recommendation

- Count of issues by severity
- Overall assessment: APPROVE / REQUEST CHANGES / COMMENT
- Highlight most critical issues to address first
- Offer to fix issues automatically

## Example Output

```
=== Peer Review: auth-refactor branch ===

Reviewed 4 files, 312 lines changed

BLOCKING:
- auth/login.ts:67 — SQL injection vulnerability
  Impact: Attacker can dump entire database
  Fix: Replace string interpolation with parameterized query
  ```typescript
  // Before
  db.query(`SELECT * FROM users WHERE email = '${email}'`)

  // After
  db.query('SELECT * FROM users WHERE email = ?', [email])
  ```

HIGH:
- auth/session.ts:123 — Race condition in session creation
  Impact: Concurrent logins can create duplicate sessions
  Fix: Use database transaction or unique constraint

- api/users.ts:89 — Missing authentication check
  Impact: Unauthenticated users can access user list
  Fix: Add auth middleware before handler

MEDIUM:
- auth/login.ts:45 — No test for failed login attempt
  Impact: Error path not verified, could break without detection
  Fix: Add test case for wrong password scenario

- utils/hash.ts:34 — Using deprecated crypto function
  Impact: May break in future Node.js versions
  Fix: Update to `crypto.scrypt` (modern alternative)

LOW:
- auth/types.ts:12 — Missing JSDoc for User interface
  Impact: Other devs need to read code to understand fields
  Fix: Add JSDoc comment explaining each field

Summary: 1 blocking, 2 high, 2 medium, 1 low

RECOMMENDATION: REQUEST CHANGES
Priority: Fix the SQL injection (BLOCKING) and add auth check (HIGH)

Should I fix the blocking and high-severity issues now? (yes/no/specific)
```

## Related Skills

- **/fresh-eyes** — Lighter-weight review of recent changes
- **/bug-hunt** — Exploratory investigation of codebase

---

# Plan Review

Review implementation plans with "fresh eyes" to catch errors, gaps, and bad assumptions before execution.

## What This Does

Systematic review of plan documents (from plan mode or written plans) looking for:
- Conceptual errors or logical violations
- Bad implicit assumptions
- Missing steps or dependencies
- Sloppy thinking or inaccurate information
- Edge cases not covered
- Risks not addressed

Can be run multiple times for iterative refinement until plan reaches "steady state".

## How to Use

- **After creating a plan:** `/plan-review` (reads current plan file)
- **Review specific plan:** `/plan-review <file-path>`
- **Multiple passes:** `/plan-review --passes 3` (run 3 times)

## Instructions

When this skill is invoked:

### Step 1: Read the Plan Document

- If in plan mode: Read the plan file specified in system message
- Otherwise: Ask user for plan file path or read most recent plan

### Step 2: Fresh Eyes Review Pass

Re-read the entire plan with fresh perspective, asking:

**Conceptual Questions:**
- Is the high-level approach sound?
- Are there logical contradictions?
- Does the plan actually solve the stated problem?

**Assumptions:**
- What implicit assumptions is this plan making?
- Are they valid? Could they be wrong?
- What happens if assumptions don't hold?

**Completeness:**
- Are all steps present from start to finish?
- Missing setup, configuration, or cleanup steps?
- What about error handling, rollback, monitoring?

**Dependencies:**
- Are dependencies between steps correctly identified?
- Any circular dependencies?
- External dependencies (APIs, services, data) accounted for?

**Risks:**
- What could go wrong?
- How will we detect failures?
- Is there a rollback/recovery plan?

**Verification:**
- How will we know if each step succeeded?
- How will we test the final result?
- Metrics or monitoring to track success?

### Step 3: Identify Issues

For each issue found, categorize:
- **CRITICAL:** Logical errors, missing essential steps, invalid assumptions
- **IMPORTANT:** Missing edge cases, unclear dependencies, risky operations
- **MINOR:** Unclear wording, optimization opportunities, documentation gaps

### Step 4: Fix Issues In-Place

Don't just report — fix the plan directly:
- Correct logical errors
- Add missing steps
- Clarify ambiguous sections
- Document assumptions explicitly
- Add verification steps
- Note risks and mitigation strategies

### Step 5: Report Changes

Summarize what was found and fixed:
- Number of issues by severity
- Key changes made to the plan
- Remaining risks or uncertainties
- Recommendation: Ready to execute? Need another pass?

### Multiple Passes

If user requests multiple passes (or issues found in first pass):
1. First pass: Catch obvious errors, logical issues
2. Second pass: Check assumptions, dependencies, edge cases
3. Third pass: Final verification, optimization, clarity

Continue until plan reaches "steady state" (no new issues found).

## Example Output

```
=== Plan Review Pass 1 ===

Read plan: /Users/danielai/.claude/projects/foo/plan.md

Issues found:

CRITICAL:
- Step 3 depends on database migration, but migration not created yet
  → Added "Create migration file" as new Step 2

- Assumption: "User records have email field" — not verified
  → Added verification step: Check schema before proceeding

IMPORTANT:
- No rollback plan if Step 5 fails
  → Added rollback procedure in Step 5 notes

- Missing verification for Step 4 (API integration)
  → Added "Test API with sample request" sub-step

MINOR:
- Step 6 wording unclear ("update the thing")
  → Clarified: "Update user.status field in database"

Changes applied to plan. Recommendation: Run one more pass to verify fixes.

Run another pass? (yes/no)
```

## Related Skills

- **/idea-wizard** — Generate ideas before planning
- **/fresh-eyes** — Review code (not plans)

---

# PRD Generator

Create detailed Product Requirements Documents that are clear, actionable, and suitable for implementation.

---

## The Job

1. Receive a feature description from the user
2. Ask 3-5 essential clarifying questions (with lettered options)
3. Generate a structured PRD based on answers
4. Save to `tasks/prd-[feature-name].md`

**Important:** Do NOT start implementing. Just create the PRD.

---

## Step 1: Clarifying Questions

Ask only critical questions where the initial prompt is ambiguous. Focus on:

- **Problem/Goal:** What problem does this solve?
- **Core Functionality:** What are the key actions?
- **Scope/Boundaries:** What should it NOT do?
- **Success Criteria:** How do we know it's done?

### Format Questions Like This:

```
1. What is the primary goal of this feature?
   A. Improve user onboarding experience
   B. Increase user retention
   C. Reduce support burden
   D. Other: [please specify]

2. Who is the target user?
   A. New users only
   B. Existing users only
   C. All users
   D. Admin users only

3. What is the scope?
   A. Minimal viable version
   B. Full-featured implementation
   C. Just the backend/API
   D. Just the UI
```

This lets users respond with "1A, 2C, 3B" for quick iteration.

---

## Step 2: PRD Structure

Generate the PRD with these sections:

### 1. Introduction/Overview
Brief description of the feature and the problem it solves.

### 2. Goals
Specific, measurable objectives (bullet list).

### 3. User Stories
Each story needs:
- **Title:** Short descriptive name
- **Description:** "As a [user], I want [feature] so that [benefit]"
- **Acceptance Criteria:** Verifiable checklist of what "done" means

Each story should be small enough to implement in one focused session.

**Format:**
```markdown
### US-001: [Title]
**Description:** As a [user], I want [feature] so that [benefit].

**Acceptance Criteria:**
- [ ] Specific verifiable criterion
- [ ] Another criterion
- [ ] Typecheck/lint passes
- [ ] **[UI stories only]** Verify in browser using dev-browser skill
```

**Important:** 
- Acceptance criteria must be verifiable, not vague. "Works correctly" is bad. "Button shows confirmation dialog before deleting" is good.
- **For any story with UI changes:** Always include "Verify in browser using dev-browser skill" as acceptance criteria. This ensures visual verification of frontend work.

### 4. Functional Requirements
Numbered list of specific functionalities:
- "FR-1: The system must allow users to..."
- "FR-2: When a user clicks X, the system must..."

Be explicit and unambiguous.

### 5. Non-Goals (Out of Scope)
What this feature will NOT include. Critical for managing scope.

### 6. Design Considerations (Optional)
- UI/UX requirements
- Link to mockups if available
- Relevant existing components to reuse

### 7. Technical Considerations (Optional)
- Known constraints or dependencies
- Integration points with existing systems
- Performance requirements

### 8. Success Metrics
How will success be measured?
- "Reduce time to complete X by 50%"
- "Increase conversion rate by 10%"

### 9. Open Questions
Remaining questions or areas needing clarification.

---

## Writing for Junior Developers

The PRD reader may be a junior developer or AI agent. Therefore:

- Be explicit and unambiguous
- Avoid jargon or explain it
- Provide enough detail to understand purpose and core logic
- Number requirements for easy reference
- Use concrete examples where helpful

---

## Output

- **Format:** Markdown (`.md`)
- **Location:** `tasks/`
- **Filename:** `prd-[feature-name].md` (kebab-case)

---

## Example PRD

```markdown
# PRD: Task Priority System

## Introduction

Add priority levels to tasks so users can focus on what matters most. Tasks can be marked as high, medium, or low priority, with visual indicators and filtering to help users manage their workload effectively.

## Goals

- Allow assigning priority (high/medium/low) to any task
- Provide clear visual differentiation between priority levels
- Enable filtering and sorting by priority
- Default new tasks to medium priority

## User Stories

### US-001: Add priority field to database
**Description:** As a developer, I need to store task priority so it persists across sessions.

**Acceptance Criteria:**
- [ ] Add priority column to tasks table: 'high' | 'medium' | 'low' (default 'medium')
- [ ] Generate and run migration successfully
- [ ] Typecheck passes

### US-002: Display priority indicator on task cards
**Description:** As a user, I want to see task priority at a glance so I know what needs attention first.

**Acceptance Criteria:**
- [ ] Each task card shows colored priority badge (red=high, yellow=medium, gray=low)
- [ ] Priority visible without hovering or clicking
- [ ] Typecheck passes
- [ ] Verify in browser using dev-browser skill

### US-003: Add priority selector to task edit
**Description:** As a user, I want to change a task's priority when editing it.

**Acceptance Criteria:**
- [ ] Priority dropdown in task edit modal
- [ ] Shows current priority as selected
- [ ] Saves immediately on selection change
- [ ] Typecheck passes
- [ ] Verify in browser using dev-browser skill

### US-004: Filter tasks by priority
**Description:** As a user, I want to filter the task list to see only high-priority items when I'm focused.

**Acceptance Criteria:**
- [ ] Filter dropdown with options: All | High | Medium | Low
- [ ] Filter persists in URL params
- [ ] Empty state message when no tasks match filter
- [ ] Typecheck passes
- [ ] Verify in browser using dev-browser skill

## Functional Requirements

- FR-1: Add `priority` field to tasks table ('high' | 'medium' | 'low', default 'medium')
- FR-2: Display colored priority badge on each task card
- FR-3: Include priority selector in task edit modal
- FR-4: Add priority filter dropdown to task list header
- FR-5: Sort by priority within each status column (high to medium to low)

## Non-Goals

- No priority-based notifications or reminders
- No automatic priority assignment based on due date
- No priority inheritance for subtasks

## Technical Considerations

- Reuse existing badge component with color variants
- Filter state managed via URL search params
- Priority stored in database, not computed

## Success Metrics

- Users can change priority in under 2 clicks
- High-priority tasks immediately visible at top of lists
- No regression in task list performance

## Open Questions

- Should priority affect task ordering within a column?
- Should we add keyboard shortcuts for priority changes?
```

---

## Checklist

Before saving the PRD:

- [ ] Asked clarifying questions with lettered options
- [ ] Incorporated user's answers
- [ ] User stories are small and specific
- [ ] Functional requirements are numbered and unambiguous
- [ ] Non-goals section defines clear boundaries
- [ ] Saved to `tasks/prd-[feature-name].md`

---

# The Premortem Planner

Before we proceed, I want you to do a "premortem" on this plan. Imagine we're 6 months in the future and this approach has completely failed. What went wrong? What assumptions did we make that turned out to be false? What edge cases did we miss? What integration issues did we overlook? What would users hate about it? Now, with that pessimistic scenario fresh in your mind, revise the plan to address the most likely failure modes.

## When to Use

- Before committing to a major implementation
- When planning risky or complex features
- To challenge assumptions before they become problems

## Tips

- Forces consideration of failure modes upfront
- Catches integration issues before they're expensive to fix
- Especially valuable for user-facing features

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/premortem-planner)*

---

# Project Opinion Elicitor

Now tell me what you actually THINK of the project-- is it even a good idea? Is it useful? Is it well designed and architected? Pragmatic? What could we do to make it more useful and compelling and intuitive/user-friendly to both humans AND to AI coding agents?

## When to Use

- After the agent has explored the codebase
- When seeking honest feedback on direction
- For reality checks on project value

## Tips

- Agents often have valuable outside perspective
- Encourages intellectual honesty
- Great for catching blind spots

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/project-opinion-elicitor)*

---

# Ralph PRD Converter

Converts existing PRDs to the prd.json format that Ralph uses for autonomous execution.

---

## The Job

Take a PRD (markdown file or text) and convert it to `prd.json` in your ralph directory.

---

## Output Format

```json
{
  "project": "[Project Name]",
  "branchName": "ralph/[feature-name-kebab-case]",
  "description": "[Feature description from PRD title/intro]",
  "userStories": [
    {
      "id": "US-001",
      "title": "[Story title]",
      "description": "As a [user], I want [feature] so that [benefit]",
      "acceptanceCriteria": [
        "Criterion 1",
        "Criterion 2",
        "Typecheck passes"
      ],
      "priority": 1,
      "passes": false,
      "notes": ""
    }
  ]
}
```

---

## Story Size: The Number One Rule

**Each story must be completable in ONE Ralph iteration (one context window).**

Ralph spawns a fresh Amp instance per iteration with no memory of previous work. If a story is too big, the LLM runs out of context before finishing and produces broken code.

### Right-sized stories:
- Add a database column and migration
- Add a UI component to an existing page
- Update a server action with new logic
- Add a filter dropdown to a list

### Too big (split these):
- "Build the entire dashboard" - Split into: schema, queries, UI components, filters
- "Add authentication" - Split into: schema, middleware, login UI, session handling
- "Refactor the API" - Split into one story per endpoint or pattern

**Rule of thumb:** If you cannot describe the change in 2-3 sentences, it is too big.

---

## Story Ordering: Dependencies First

Stories execute in priority order. Earlier stories must not depend on later ones.

**Correct order:**
1. Schema/database changes (migrations)
2. Server actions / backend logic
3. UI components that use the backend
4. Dashboard/summary views that aggregate data

**Wrong order:**
1. UI component (depends on schema that does not exist yet)
2. Schema change

---

## Acceptance Criteria: Must Be Verifiable

Each criterion must be something Ralph can CHECK, not something vague.

### Good criteria (verifiable):
- "Add `status` column to tasks table with default 'pending'"
- "Filter dropdown has options: All, Active, Completed"
- "Clicking delete shows confirmation dialog"
- "Typecheck passes"
- "Tests pass"

### Bad criteria (vague):
- "Works correctly"
- "User can do X easily"
- "Good UX"
- "Handles edge cases"

### Always include as final criterion:
```
"Typecheck passes"
```

For stories with testable logic, also include:
```
"Tests pass"
```

### For stories that change UI, also include:
```
"Verify in browser using dev-browser skill"
```

Frontend stories are NOT complete until visually verified. Ralph will use the dev-browser skill to navigate to the page, interact with the UI, and confirm changes work.

---

## Conversion Rules

1. **Each user story becomes one JSON entry**
2. **IDs**: Sequential (US-001, US-002, etc.)
3. **Priority**: Based on dependency order, then document order
4. **All stories**: `passes: false` and empty `notes`
5. **branchName**: Derive from feature name, kebab-case, prefixed with `ralph/`
6. **Always add**: "Typecheck passes" to every story's acceptance criteria

---

## Splitting Large PRDs

If a PRD has big features, split them:

**Original:**
> "Add user notification system"

**Split into:**
1. US-001: Add notifications table to database
2. US-002: Create notification service for sending notifications
3. US-003: Add notification bell icon to header
4. US-004: Create notification dropdown panel
5. US-005: Add mark-as-read functionality
6. US-006: Add notification preferences page

Each is one focused change that can be completed and verified independently.

---

## Example

**Input PRD:**
```markdown
# Task Status Feature

Add ability to mark tasks with different statuses.

## Requirements
- Toggle between pending/in-progress/done on task list
- Filter list by status
- Show status badge on each task
- Persist status in database
```

**Output prd.json:**
```json
{
  "project": "TaskApp",
  "branchName": "ralph/task-status",
  "description": "Task Status Feature - Track task progress with status indicators",
  "userStories": [
    {
      "id": "US-001",
      "title": "Add status field to tasks table",
      "description": "As a developer, I need to store task status in the database.",
      "acceptanceCriteria": [
        "Add status column: 'pending' | 'in_progress' | 'done' (default 'pending')",
        "Generate and run migration successfully",
        "Typecheck passes"
      ],
      "priority": 1,
      "passes": false,
      "notes": ""
    },
    {
      "id": "US-002",
      "title": "Display status badge on task cards",
      "description": "As a user, I want to see task status at a glance.",
      "acceptanceCriteria": [
        "Each task card shows colored status badge",
        "Badge colors: gray=pending, blue=in_progress, green=done",
        "Typecheck passes",
        "Verify in browser using dev-browser skill"
      ],
      "priority": 2,
      "passes": false,
      "notes": ""
    },
    {
      "id": "US-003",
      "title": "Add status toggle to task list rows",
      "description": "As a user, I want to change task status directly from the list.",
      "acceptanceCriteria": [
        "Each row has status dropdown or toggle",
        "Changing status saves immediately",
        "UI updates without page refresh",
        "Typecheck passes",
        "Verify in browser using dev-browser skill"
      ],
      "priority": 3,
      "passes": false,
      "notes": ""
    },
    {
      "id": "US-004",
      "title": "Filter tasks by status",
      "description": "As a user, I want to filter the list to see only certain statuses.",
      "acceptanceCriteria": [
        "Filter dropdown: All | Pending | In Progress | Done",
        "Filter persists in URL params",
        "Typecheck passes",
        "Verify in browser using dev-browser skill"
      ],
      "priority": 4,
      "passes": false,
      "notes": ""
    }
  ]
}
```

---

## Archiving Previous Runs

**Before writing a new prd.json, check if there is an existing one from a different feature:**

1. Read the current `prd.json` if it exists
2. Check if `branchName` differs from the new feature's branch name
3. If different AND `progress.txt` has content beyond the header:
   - Create archive folder: `archive/YYYY-MM-DD-feature-name/`
   - Copy current `prd.json` and `progress.txt` to archive
   - Reset `progress.txt` with fresh header

**The ralph.sh script handles this automatically** when you run it, but if you are manually updating prd.json between runs, archive first.

---

## Checklist Before Saving

Before writing prd.json, verify:

- [ ] **Previous run archived** (if prd.json exists with different branchName, archive it first)
- [ ] Each story is completable in one iteration (small enough)
- [ ] Stories are ordered by dependency (schema to backend to UI)
- [ ] Every story has "Typecheck passes" as criterion
- [ ] UI stories have "Verify in browser using dev-browser skill" as criterion
- [ ] Acceptance criteria are verifiable (not vague)
- [ ] No story depends on a later story

---

# RCH — Remote Compilation Helper

Transparently offloads `cargo build`, `bun test`, `gcc` to remote workers. Same commands, faster builds.

<!-- TOC: Diagnosis | Quick Fixes | Worker Config | Install | Commands | Debug | References -->

## Diagnosis Loop

```bash
rch doctor              # What's broken?
rch doctor --fix        # Auto-fix common issues
rch doctor --verbose    # All checks passed? Ready to use
```

**If `--fix` can't solve it → see Quick Fixes or references.**

---

## Quick Fixes (Copy-Paste)

| Symptom | Command |
|---------|---------|
| SSH auth fails | `eval $(ssh-agent) && ssh-add ~/.ssh/your_key` |
| Daemon not running | `rm -f /tmp/rch.sock && rchd &` |
| Hook not installed | `rch hook install --force` |
| No workers available | `vim ~/.config/rch/workers.toml` (add workers) |
| Socket permission | `rm /tmp/rch.sock && rchd` |
| Stale socket | `lsof /tmp/rch.sock` → kill stale process |

---

## Worker Config (`~/.config/rch/workers.toml`)

```toml
[[workers]]
id = "builder"
host = "192.168.1.100"        # IP or hostname
user = "ubuntu"
identity_file = "~/.ssh/id_ed25519"
total_slots = 8               # ≈ CPU cores - 2
priority = 100                # Higher = preferred
tags = ["rust", "bun"]        # Optional capabilities
```

### Auto-Discover from SSH Config

```bash
rch workers discover --from-ssh-config --dry-run  # Preview
rch workers discover --from-ssh-config            # Add to config
```

### Verify Workers

```bash
rch workers probe --all         # Test all workers
rch workers probe worker1 -v    # Test single, verbose
rch workers list                # Show status
```

---

## Commands

- `rch doctor` - Diagnose issues
- `rch status` - Show daemon status
- `rch workers probe --all` - Test all workers
- `rch workers discover --from-ssh-config` - Auto-discover workers
- `rch fleet status` - Show all workers
- `rch self-test` - Full end-to-end verification

---

## Fleet Operations

```bash
rch fleet status             # Show all workers
rch fleet preflight --all    # Verify workers ready
rch fleet deploy --all       # Deploy rch-wkr to workers
rch self-test                # Full end-to-end verification
```

---

## Anti-Patterns

| Don't | Why | Do Instead |
|-------|-----|------------|
| Run daemon as root | Security risk | `systemctl --user start rchd` |
| Skip `rch doctor` | Miss config issues | Always verify first |
| Use `--force` blindly | May break hook | Check `rch hook status` first |
| Ignore transfer errors | Indicates network/disk issues | Check worker disk space, network |

---

## Debug

```bash
RCH_LOG=debug cargo build    # Show hook decisions
RCH_DRY_RUN=1 cargo check    # Test without remote execution
rch doctor --json > diag.json  # Export diagnostics
```

---

## Docs

Full documentation: https://github.com/Dicklesworthstone/remote_compilation_helper

---

# The README Reviser

Update the README and other documentation to reflect all of the recent changes to the project.

Frame all updates as if they were always present (i.e., don't say "we added X" or "X is now Y" — just describe the current state).

Make sure to add any new commands, options, or features that have been added.

## When to Use

- After completing a feature or significant code change
- When documentation is out of sync with code
- Before releasing a new version
- When onboarding new contributors

## Tips

- Run after every significant feature completion
- Check for removed features that need to be undocumented
- Ensure examples still work with current code

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/readme-reviser)*

---

# The Robot-Mode Maker

Design and implement a "robot mode" CLI for this project.

The CLI should be optimized for use by AI coding agents:

1. **JSON Output**: Add --json flag to every command for machine-readable output
2. **Quick Start**: Running with no args shows help in ~100 tokens
3. **Structured Errors**: Error responses include code, message, suggestions
4. **TTY Detection**: Auto-switch to JSON when piped
5. **Exit Codes**: Meaningful codes (0=success, 1=not found, 2=invalid args, etc.)
6. **Token Efficient**: Dense, minimal output that respects context limits

Think about what information an AI agent would need and how to present it most efficiently.

Design the interface before implementing.

## When to Use

- When building a new CLI tool
- When adding agent-friendly features to existing CLI
- When optimizing human-centric tools for AI use

## Tips

- Start with the most common agent workflows
- Test output token counts to ensure efficiency
- Include fuzzy search for discoverability

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/robot-mode-maker)*

---

# Stripe-Level UI

I want you to do a spectacular job building absolutely world-class UI/UX components, with an intense focus on making the most visually appealing, user-friendly, intuitive, slick, polished, "Stripe level" of quality UI/UX possible for this that leverages the good libraries that are already part of the project.

## When to Use

- When building new UI components
- When polishing existing interfaces
- When you want premium, professional-quality frontend

## Tips

- Works great with Next.js, React, and Tailwind projects
- Reference Stripe's design system for inspiration
- Combine with existing component libraries like shadcn/ui

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/stripe-level-ui)*

---

# The Stub Eliminator

I need you to look for stubs, placeholders, mocks, of ANY KIND. These ALL must be replaced with FULLY FLESHED OUT, working, correct, performant, idiomatic code as per the beads. Do this meticulously and carefully!

## When to Use

- Before shipping to production
- When auditing code quality
- After rapid prototyping phases
- To ensure feature completeness

## Tips

- Critical for production readiness
- Mocks in production code are a major red flag
- Run this before any major release

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/stub-eliminator)*

---

# System Weaknesses Analyzer

Based on everything you've seen, what are the weakest/worst parts of the system? What is most needing of fresh ideas and innovative/creative/clever improvements?

## When to Use

- After the agent has explored the codebase thoroughly
- When you want to identify areas for improvement
- As a starting point for refactoring discussions

## Tips

- Best used after the agent has done substantial work in the session
- Follow up with prompts to actually implement the improvements
- Combine with a TODO list prompt for tracking execution

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/system-weaknesses)*
