---
name: deep-project-primer
description: Essential first step to fully understand a project before any work
---
# Deep Project Primer

First read ALL of the AGENTS.md file and README.md file super carefully and understand ALL of both! Then use your code investigation agent mode to fully understand the code, and technical architecture and purpose of the project.

## When to Use

- At the start of any new coding session
- When working on an unfamiliar project
- After context compaction to restore understanding
- Before any major architectural decisions

## Tips

- Always use this before significant work
- Essential for maintaining project coherence
- Prevents agents from making uninformed changes

---

*From [JeffreysPrompts.com](https://jeffreysprompts.com/prompts/deep-project-primer)*

